import QRCode from 'qrcode';

/**
 * Standard Thai PromptPay QR payload generator (EMVCo specification)
 * Supports Mobile number (10 digits e.g. 0840148961) or National ID / Tax ID (13 digits e.g. 1401701236251)
 */

function crc16(data: string): string {
  let crc = 0xffff;
  for (let i = 0; i < data.length; i++) {
    let x = ((crc >> 8) ^ data.charCodeAt(i)) & 0xff;
    x ^= x >> 4;
    crc = ((crc << 8) ^ (x << 12) ^ (x << 5) ^ x) & 0xffff;
  }
  return crc.toString(16).toUpperCase().padStart(4, '0');
}

function formatTLV(tag: string, value: string): string {
  const length = value.length.toString().padStart(2, '0');
  return `${tag}${length}${value}`;
}

export function generatePromptPayPayload(target: string, amount?: number): string {
  // Clean target
  const sanitized = target.replace(/[^0-9]/g, '');
  let formattedTarget = '';
  let subTag = '';

  if (sanitized.length === 13) {
    // Tax ID / National ID
    subTag = '02';
    formattedTarget = sanitized;
  } else if (sanitized.length >= 9 && sanitized.length <= 10) {
    // Phone Number (Convert 0840148961 to 0066840148961)
    subTag = '01';
    let phone = sanitized;
    if (phone.startsWith('0')) {
      phone = '66' + phone.substring(1);
    }
    formattedTarget = phone.padStart(13, '0');
  } else {
    subTag = '02';
    formattedTarget = sanitized.padStart(13, '0');
  }

  // Aid
  const aid = formatTLV('00', 'A000000677010111');
  const targetTag = formatTLV(subTag, formattedTarget);
  const merchantAccountInfo = formatTLV('29', aid + targetTag);

  let payload = '';
  payload += formatTLV('00', '01'); // Payload Format Indicator
  payload += formatTLV('01', amount ? '12' : '11'); // 11 = Static QR, 12 = Dynamic QR
  payload += merchantAccountInfo;
  payload += formatTLV('53', '764'); // Transaction Currency (764 = THB)

  if (amount && amount > 0) {
    payload += formatTLV('54', amount.toFixed(2));
  }

  payload += formatTLV('58', 'TH'); // Country Code
  payload += '6304'; // CRC placeholder

  const calculatedCrc = crc16(payload);
  return payload + calculatedCrc;
}

export async function generateQrDataUrl(text: string): Promise<string> {
  try {
    return await QRCode.toDataURL(text, {
      errorCorrectionLevel: 'M',
      margin: 2,
      width: 260,
      color: {
        dark: '#1e293b',
        light: '#ffffff',
      },
    });
  } catch (err) {
    console.error('Error generating QR code', err);
    return '';
  }
}
