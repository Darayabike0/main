import { InvoiceItem } from '../types';
import { thaiBahtText } from './thaiBahtText';

export interface CalculationResult {
  subtotal: number;
  itemDiscountTotal: number;
  overallDiscountAmount: number;
  netBeforeVat: number;
  vatAmount: number;
  withholdingTaxAmount: number;
  grandTotal: number;
  netPayable: number;
  bahtText: string;
}

export function calculateInvoiceTotals(
  items: InvoiceItem[],
  vatType: 'included' | 'excluded' | 'none',
  vatRate: number = 7,
  withholdingTaxRate: number = 0,
  overallDiscountType: 'percent' | 'amount' = 'amount',
  overallDiscountValue: number = 0
): CalculationResult {
  // 1. Calculate items subtotal and per-item discounts
  let rawSubtotal = 0;
  let itemDiscountTotal = 0;
  let itemsAfterDiscountTotal = 0;

  items.forEach(item => {
    const rawItemPrice = (item.quantity || 0) * (item.unitPrice || 0);
    rawSubtotal += rawItemPrice;

    let itemDiscount = 0;
    if (item.discountType === 'percent') {
      itemDiscount = rawItemPrice * ((item.discountValue || 0) / 100);
    } else {
      itemDiscount = item.discountValue || 0;
    }
    itemDiscount = Math.min(itemDiscount, rawItemPrice);
    itemDiscountTotal += itemDiscount;

    itemsAfterDiscountTotal += (rawItemPrice - itemDiscount);
  });

  // 2. Overall discount
  let overallDiscountAmount = 0;
  if (overallDiscountType === 'percent') {
    overallDiscountAmount = itemsAfterDiscountTotal * ((overallDiscountValue || 0) / 100);
  } else {
    overallDiscountAmount = overallDiscountValue || 0;
  }
  overallDiscountAmount = Math.min(overallDiscountAmount, itemsAfterDiscountTotal);

  const basePriceAfterAllDiscounts = itemsAfterDiscountTotal - overallDiscountAmount;

  let netBeforeVat = 0;
  let vatAmount = 0;
  let grandTotal = 0;

  if (vatType === 'included') {
    // Prices include VAT 7%
    // Base = Price / 1.07
    // VAT = Price - Base
    grandTotal = basePriceAfterAllDiscounts;
    if (vatRate > 0) {
      netBeforeVat = grandTotal / (1 + vatRate / 100);
      vatAmount = grandTotal - netBeforeVat;
    } else {
      netBeforeVat = grandTotal;
      vatAmount = 0;
    }
  } else if (vatType === 'excluded') {
    // Prices exclude VAT
    netBeforeVat = basePriceAfterAllDiscounts;
    if (vatRate > 0) {
      vatAmount = netBeforeVat * (vatRate / 100);
      grandTotal = netBeforeVat + vatAmount;
    } else {
      vatAmount = 0;
      grandTotal = netBeforeVat;
    }
  } else {
    // None / Exempt
    netBeforeVat = basePriceAfterAllDiscounts;
    vatAmount = 0;
    grandTotal = basePriceAfterAllDiscounts;
  }

  // 3. Withholding Tax (คำนวณจากยอดก่อน VAT)
  let withholdingTaxAmount = 0;
  if (withholdingTaxRate > 0) {
    withholdingTaxAmount = netBeforeVat * (withholdingTaxRate / 100);
  }

  const netPayable = Math.max(0, grandTotal - withholdingTaxAmount);

  // Round values nicely
  const roundedNetBeforeVat = Math.round(netBeforeVat * 100) / 100;
  const roundedVatAmount = Math.round(vatAmount * 100) / 100;
  const roundedGrandTotal = Math.round(grandTotal * 100) / 100;
  const roundedWithholding = Math.round(withholdingTaxAmount * 100) / 100;
  const roundedNetPayable = Math.round(netPayable * 100) / 100;

  return {
    subtotal: Math.round(rawSubtotal * 100) / 100,
    itemDiscountTotal: Math.round(itemDiscountTotal * 100) / 100,
    overallDiscountAmount: Math.round(overallDiscountAmount * 100) / 100,
    netBeforeVat: roundedNetBeforeVat,
    vatAmount: roundedVatAmount,
    withholdingTaxAmount: roundedWithholding,
    grandTotal: roundedGrandTotal,
    netPayable: roundedNetPayable,
    bahtText: thaiBahtText(roundedNetPayable || roundedGrandTotal),
  };
}
