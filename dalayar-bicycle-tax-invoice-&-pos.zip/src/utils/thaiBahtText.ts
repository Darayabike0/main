/**
 * Thai Baht Text Converter (แปลงตัวเลขเป็นตัวหนังสือภาษาไทย สำหรับใบกำกับภาษี)
 * Example: 1250.50 => "หนึ่งพันสองร้อยห้าสิบบาทห้าสิบสตางค์"
 * Example: 50000.00 => "ห้าหมื่นบาทถ้วน"
 */

const THAI_DIGITS = ['ศูนย์', 'หนึ่ง', 'สอง', 'สาม', 'สี่', 'ห้า', 'หก', 'เจ็ด', 'แปด', 'เก้า'];
const THAI_UNITS = ['', 'สิบ', 'ร้อย', 'พัน', 'หมื่น', 'แสน', 'ล้าน'];

function convertGroup(numberStr: string, isMillion: boolean = false): string {
  let result = '';
  const len = numberStr.length;

  for (let i = 0; i < len; i++) {
    const digit = parseInt(numberStr[i], 10);
    const unitPos = len - i - 1;

    if (digit !== 0) {
      if (unitPos === 1 && digit === 1) {
        // 'สิบ' instead of 'หนึ่งสิบ'
        result += 'สิบ';
      } else if (unitPos === 1 && digit === 2) {
        // 'ยี่สิบ' instead of 'สองสิบ'
        result += 'ยี่สิบ';
      } else if (unitPos === 0 && digit === 1 && len > 1) {
        // 'เอ็ด' when last digit in multi-digit number
        const prevDigit = parseInt(numberStr[i - 1], 10);
        if (prevDigit === 0 && len > 2 && isMillion) {
          result += 'หนึ่ง';
        } else {
          result += 'เอ็ด';
        }
      } else {
        result += THAI_DIGITS[digit] + THAI_UNITS[unitPos];
      }
    }
  }

  return result;
}

export function thaiBahtText(amount: number): string {
  if (isNaN(amount) || amount === 0) {
    return 'ศูนย์บาทถ้วน';
  }

  const isNegative = amount < 0;
  const absAmount = Math.abs(amount);
  
  // Round to 2 decimal places
  const fixed = absAmount.toFixed(2);
  const [integerPart, decimalPart] = fixed.split('.');

  let bahtStr = '';
  
  // Handle numbers larger than a million
  if (integerPart.length > 6) {
    const millionsCount = Math.floor((integerPart.length - 1) / 6);
    let remaining = integerPart;
    const parts: string[] = [];

    while (remaining.length > 6) {
      parts.unshift(remaining.slice(-6));
      remaining = remaining.slice(0, -6);
    }
    parts.unshift(remaining);

    for (let idx = 0; idx < parts.length; idx++) {
      const groupText = convertGroup(parts[idx], idx > 0);
      if (groupText) {
        bahtStr += groupText;
        if (idx < parts.length - 1) {
          bahtStr += 'ล้าน';
        }
      }
    }
  } else {
    bahtStr = convertGroup(integerPart);
  }

  if (!bahtStr) {
    bahtStr = 'ศูนย์';
  }

  let satangStr = '';
  const satangVal = parseInt(decimalPart, 10);
  
  if (satangVal > 0) {
    satangStr = convertGroup(decimalPart);
  }

  let fullText = (isNegative ? 'ลบ' : '') + bahtStr + 'บาท';
  if (satangVal > 0) {
    fullText += satangStr + 'สตางค์';
  } else {
    fullText += 'ถ้วน';
  }

  return fullText;
}

export function formatCurrency(amount: number, showSymbol: boolean = true): string {
  const formatted = new Intl.NumberFormat('th-TH', {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  }).format(amount || 0);

  return showSymbol ? `฿${formatted}` : formatted;
}
