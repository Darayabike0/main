/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { 
  InvoiceDocument, 
  ProductItem, 
  Customer 
} from './types';
import { DALAYAR_COMPANY_INFO } from './data/companyInfo';
import { DEFAULT_CATALOG } from './data/defaultCatalog';
import { DEFAULT_CUSTOMERS } from './data/defaultCustomers';
import { INITIAL_INVOICES } from './data/defaultInvoices';

import { Header } from './components/Header';
import { InvoiceList } from './components/InvoiceList';
import { TaxInvoiceDocument } from './components/TaxInvoiceDocument';
import { ThermalReceipt } from './components/ThermalReceipt';
import { InvoiceEditor } from './components/InvoiceEditor';
import { QuickPOS } from './components/QuickPOS';
import { CatalogManager } from './components/CatalogManager';
import { CustomerManager } from './components/CustomerManager';
import { SalesDashboard } from './components/SalesDashboard';

import { 
  ArrowLeft, 
  FileText, 
  Printer, 
  Plus, 
  Bike,
  RotateCcw,
  Check
} from 'lucide-react';

export default function App() {
  // Local storage persistence
  const [invoices, setInvoices] = useState<InvoiceDocument[]>(() => {
    const saved = localStorage.getItem('dalayar_invoices_v1');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        return INITIAL_INVOICES;
      }
    }
    return INITIAL_INVOICES;
  });

  const [catalog, setCatalog] = useState<ProductItem[]>(() => {
    const saved = localStorage.getItem('dalayar_catalog_v1');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        return DEFAULT_CATALOG;
      }
    }
    return DEFAULT_CATALOG;
  });

  const [customers, setCustomers] = useState<Customer[]>(() => {
    const saved = localStorage.getItem('dalayar_customers_v1');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        return DEFAULT_CUSTOMERS;
      }
    }
    return DEFAULT_CUSTOMERS;
  });

  // Navigation state
  const [activeTab, setActiveTab] = useState<'invoices' | 'pos' | 'catalog' | 'customers' | 'analytics'>('invoices');
  const [viewMode, setViewMode] = useState<'list' | 'view_invoice' | 'edit_invoice' | 'new_invoice'>('list');
  const [selectedInvoice, setSelectedInvoice] = useState<InvoiceDocument | null>(invoices[0] || null);
  const [activeSlipInvoice, setActiveSlipInvoice] = useState<InvoiceDocument | null>(null);

  // Sync with LocalStorage
  useEffect(() => {
    localStorage.setItem('dalayar_invoices_v1', JSON.stringify(invoices));
  }, [invoices]);

  useEffect(() => {
    localStorage.setItem('dalayar_catalog_v1', JSON.stringify(catalog));
  }, [catalog]);

  useEffect(() => {
    localStorage.setItem('dalayar_customers_v1', JSON.stringify(customers));
  }, [customers]);

  // Actions
  const handleNewInvoice = () => {
    setSelectedInvoice(null);
    setViewMode('new_invoice');
    setActiveTab('invoices');
  };

  const handleOpenInvoice = (inv: InvoiceDocument) => {
    setSelectedInvoice(inv);
    setViewMode('view_invoice');
    setActiveTab('invoices');
  };

  const handleEditInvoice = (inv: InvoiceDocument) => {
    setSelectedInvoice(inv);
    setViewMode('edit_invoice');
    setActiveTab('invoices');
  };

  const handleSaveInvoice = (inv: InvoiceDocument) => {
    const exists = invoices.some(i => i.id === inv.id);
    if (exists) {
      setInvoices(invoices.map(i => i.id === inv.id ? inv : i));
    } else {
      setInvoices([inv, ...invoices]);
    }
    setSelectedInvoice(inv);
    setViewMode('view_invoice');
  };

  const handleDeleteInvoice = (id: string) => {
    if (window.confirm('คุณต้องการลบเอกสารนี้หรือไม่?')) {
      const updated = invoices.filter(i => i.id !== id);
      setInvoices(updated);
      if (selectedInvoice?.id === id) {
        setSelectedInvoice(updated[0] || null);
        setViewMode('list');
      }
    }
  };

  const handleDuplicateInvoice = (inv: InvoiceDocument) => {
    const today = new Date();
    const yyyymm = `${today.getFullYear()}${String(today.getMonth() + 1).padStart(2, '0')}`;
    const randomSeq = String(Math.floor(Math.random() * 900) + 100);
    
    const duplicated: InvoiceDocument = {
      ...inv,
      id: `inv-${Date.now()}`,
      documentNumber: `TAX-${yyyymm}-${randomSeq}`,
      issueDate: today.toISOString().split('T')[0],
      dueDate: today.toISOString().split('T')[0],
      status: 'draft',
    };
    
    setInvoices([duplicated, ...invoices]);
    setSelectedInvoice(duplicated);
    setViewMode('view_invoice');
  };

  // Catalog actions
  const handleAddProduct = (prod: ProductItem) => {
    setCatalog([prod, ...catalog]);
  };

  const handleUpdateProduct = (prod: ProductItem) => {
    setCatalog(catalog.map(p => p.id === prod.id ? prod : p));
  };

  const handleDeleteProduct = (id: string) => {
    if (window.confirm('คุณต้องการลบรายการสินค้านี้หรือไม่?')) {
      setCatalog(catalog.filter(p => p.id !== id));
    }
  };

  // Customer actions
  const handleAddCustomer = (cust: Customer) => {
    setCustomers([cust, ...customers]);
  };

  const handleUpdateCustomer = (cust: Customer) => {
    setCustomers(customers.map(c => c.id === cust.id ? cust : c));
  };

  const handleDeleteCustomer = (id: string) => {
    if (window.confirm('คุณต้องการลบรายชื่อลูกค้านี้หรือไม่?')) {
      setCustomers(customers.filter(c => c.id !== id));
    }
  };

  const handleCreateInvoiceForCustomer = (cust: Customer) => {
    setSelectedInvoice({
      id: `inv-${Date.now()}`,
      documentNumber: `TAX-${new Date().getFullYear()}${String(new Date().getMonth() + 1).padStart(2, '0')}-${Math.floor(Math.random() * 900 + 100)}`,
      type: 'TAX_INVOICE_RECEIPT',
      issueDate: new Date().toISOString().split('T')[0],
      dueDate: new Date().toISOString().split('T')[0],
      salesPerson: 'ดาราญาร์ (DALAYAR Staff)',
      customer: cust,
      items: [
        {
          id: `item-${Date.now()}`,
          code: 'BK-GRV-01',
          name: 'จักรยานกราเวล Dalayar All-Road Gravel Disc (Carbon Frame)',
          description: 'เฟรมคาร์บอน T800, ชุดขับ Shimano GRX 11-Speed',
          serialNumber: `DLR-GRV-2026-${Math.floor(Math.random() * 8999 + 1000)}`,
          category: 'bicycle',
          quantity: 1,
          unit: 'คัน',
          unitPrice: 45900,
          discountType: 'amount',
          discountValue: 0,
          totalPrice: 45900,
        }
      ],
      vatType: 'included',
      vatRate: 7,
      withholdingTaxRate: 0,
      overallDiscountType: 'amount',
      overallDiscountValue: 0,
      subtotal: 45900,
      itemDiscountTotal: 0,
      overallDiscountAmount: 0,
      netBeforeVat: 42897.20,
      vatAmount: 3002.80,
      withholdingTaxAmount: 0,
      grandTotal: 45900,
      netPayable: 45900,
      bahtText: 'สี่หมื่นห้าพันเก้าร้อยบาทถ้วน',
      payment: {
        method: 'promptpay',
        paidAmount: 45900,
        changeAmount: 0,
        paidAt: `${new Date().toISOString().split('T')[0]} 10:00`,
        promptPayId: DALAYAR_COMPANY_INFO.promptpayId,
      },
      status: 'issued',
      authorizedSignatureName: 'ดาราญาร์ ดิษฐ์ (ผู้มีอำนาจลงนาม)',
      authorizedSignatureTitle: 'Managing Director / กรรมการผู้จัดการ',
      isSigned: true,
      signatureDate: new Date().toISOString().split('T')[0],
      copyType: 'original',
    });
    setViewMode('new_invoice');
    setActiveTab('invoices');
  };

  // Reset demo data
  const handleResetData = () => {
    if (window.confirm('ต้องการรีเซ็ตข้อมูลทั้งหมดกลับเป็นค่าเริ่มต้นหรือไม่?')) {
      setInvoices(INITIAL_INVOICES);
      setCatalog(DEFAULT_CATALOG);
      setCustomers(DEFAULT_CUSTOMERS);
      setSelectedInvoice(INITIAL_INVOICES[0]);
      localStorage.removeItem('dalayar_invoices_v1');
      localStorage.removeItem('dalayar_catalog_v1');
      localStorage.removeItem('dalayar_customers_v1');
    }
  };

  return (
    <div className="min-h-screen bg-stone-100/70 text-stone-900 flex flex-col antialiased selection:bg-amber-500 selection:text-stone-950 font-['Prompt',sans-serif]">
      
      {/* App Header */}
      <Header
        activeTab={activeTab}
        setActiveTab={(tab) => {
          setActiveTab(tab);
          if (tab === 'invoices') {
            setViewMode('list');
          }
        }}
        onNewInvoice={handleNewInvoice}
        invoiceCount={invoices.length}
      />

      {/* Main Content Area */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 py-6 space-y-6">
        
        {/* Tab 1: Invoices */}
        {activeTab === 'invoices' && (
          <div>
            {viewMode === 'list' && (
              <InvoiceList
                invoices={invoices}
                onOpenInvoice={handleOpenInvoice}
                onEditInvoice={handleEditInvoice}
                onPrintSlip={(inv) => setActiveSlipInvoice(inv)}
                onDeleteInvoice={handleDeleteInvoice}
                onDuplicateInvoice={handleDuplicateInvoice}
                onNewInvoice={handleNewInvoice}
              />
            )}

            {viewMode === 'view_invoice' && selectedInvoice && (
              <div className="space-y-4">
                {/* Back to list button */}
                <div className="no-print flex items-center justify-between">
                  <button
                    onClick={() => setViewMode('list')}
                    className="inline-flex items-center gap-1.5 text-xs font-semibold text-stone-600 hover:text-stone-900 bg-white px-3 py-1.5 rounded-xl border border-stone-200 shadow-2xs transition-all hover:bg-stone-50"
                  >
                    <ArrowLeft className="w-4 h-4" />
                    <span>กลับไปหน้ารวมเอกสาร</span>
                  </button>

                  <div className="flex items-center gap-2">
                    <span className="text-xs text-stone-500 font-medium">
                      กำลังดู: <strong className="text-stone-800">{selectedInvoice.documentNumber}</strong>
                    </span>
                  </div>
                </div>

                <TaxInvoiceDocument
                  invoice={selectedInvoice}
                  onEdit={() => setViewMode('edit_invoice')}
                  onPrintThermal={() => setActiveSlipInvoice(selectedInvoice)}
                />
              </div>
            )}

            {(viewMode === 'new_invoice' || viewMode === 'edit_invoice') && (
              <div className="space-y-4">
                <div className="no-print flex items-center justify-between">
                  <button
                    onClick={() => setViewMode(selectedInvoice ? 'view_invoice' : 'list')}
                    className="inline-flex items-center gap-1.5 text-xs font-semibold text-stone-600 hover:text-stone-900 bg-white px-3 py-1.5 rounded-xl border border-stone-200 shadow-2xs transition-all hover:bg-stone-50"
                  >
                    <ArrowLeft className="w-4 h-4" />
                    <span>ย้อนกลับ</span>
                  </button>
                </div>

                <InvoiceEditor
                  initialInvoice={viewMode === 'edit_invoice' ? selectedInvoice : (selectedInvoice?.customer ? selectedInvoice : null)}
                  catalog={catalog}
                  customers={customers}
                  onSave={handleSaveInvoice}
                  onPreview={(inv) => {
                    setSelectedInvoice(inv);
                    setViewMode('view_invoice');
                  }}
                  onCancel={() => setViewMode(selectedInvoice ? 'view_invoice' : 'list')}
                />
              </div>
            )}
          </div>
        )}

        {/* Tab 2: Point of Sale (POS) */}
        {activeTab === 'pos' && (
          <QuickPOS
            catalog={catalog}
            customers={customers}
            onCompleteSale={(newInv) => {
              setInvoices([newInv, ...invoices]);
              setSelectedInvoice(newInv);
            }}
            onOpenDocument={(inv) => {
              setSelectedInvoice(inv);
              setActiveTab('invoices');
              setViewMode('view_invoice');
            }}
            onOpenSlip={(inv) => {
              setActiveSlipInvoice(inv);
            }}
          />
        )}

        {/* Tab 3: Catalog Manager */}
        {activeTab === 'catalog' && (
          <CatalogManager
            catalog={catalog}
            onAddProduct={handleAddProduct}
            onUpdateProduct={handleUpdateProduct}
            onDeleteProduct={handleDeleteProduct}
          />
        )}

        {/* Tab 4: Customer Manager */}
        {activeTab === 'customers' && (
          <CustomerManager
            customers={customers}
            onAddCustomer={handleAddCustomer}
            onUpdateCustomer={handleUpdateCustomer}
            onDeleteCustomer={handleDeleteCustomer}
            onCreateInvoiceForCustomer={handleCreateInvoiceForCustomer}
          />
        )}

        {/* Tab 5: Analytics & Tax Reports */}
        {activeTab === 'analytics' && (
          <SalesDashboard
            invoices={invoices}
            onOpenInvoice={(inv) => {
              setSelectedInvoice(inv);
              setActiveTab('invoices');
              setViewMode('view_invoice');
            }}
          />
        )}

      </main>

      {/* 80mm Thermal Receipt Modal */}
      {activeSlipInvoice && (
        <ThermalReceipt
          invoice={activeSlipInvoice}
          onClose={() => setActiveSlipInvoice(null)}
        />
      )}

      {/* Footer */}
      <footer className="no-print bg-white border-t border-stone-200/80 mt-12 py-6 text-stone-500 text-xs">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <div className="w-6 h-6 rounded-lg bg-stone-900 text-amber-400 flex items-center justify-center font-bold text-[10px]">
              <Bike className="w-3.5 h-3.5" />
            </div>
            <span>
              <strong>{DALAYAR_COMPANY_INFO.nameEn}</strong> • {DALAYAR_COMPANY_INFO.nameTh}
            </span>
          </div>

          <div className="flex items-center gap-4 text-stone-500">
            <span>เลขประจำตัวผู้เสียภาษี: <strong className="font-mono text-stone-700">{DALAYAR_COMPANY_INFO.taxId}</strong></span>
            <span>•</span>
            <button
              onClick={handleResetData}
              className="text-stone-400 hover:text-rose-600 flex items-center gap-1 text-[11px]"
              title="รีเซ็ตข้อมูลตัวอย่างกลับเป็นค่าเริ่มต้น"
            >
              <RotateCcw className="w-3 h-3" />
              รีเซ็ตข้อมูลตัวอย่าง
            </button>
          </div>
        </div>
      </footer>

    </div>
  );
}
