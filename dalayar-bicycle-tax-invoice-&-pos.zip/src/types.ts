export type DocumentType = 
  | 'TAX_INVOICE_RECEIPT' // ใบกำกับภาษี / ใบเสร็จรับเงิน
  | 'TAX_INVOICE'         // ใบกำกับภาษี
  | 'RECEIPT'             // ใบเสร็จรับเงิน
  | 'QUOTATION'           // ใบเสนอราคา
  | 'INVOICE'             // ใบแจ้งหนี้ / ใบวางบิล
  | 'DELIVERY_NOTE'       // ใบส่งของ / ใบกำกับภาษี
  | 'RECEIPT_SLIP';       // ใบเสร็จอย่างย่อ (80mm)

export type CustomerType = 'individual' | 'company';

export interface Customer {
  id: string;
  type: CustomerType;
  name: string;
  taxId?: string; // 13 digits
  branchType?: 'head' | 'branch';
  branchNumber?: string; // e.g. 00000 or สาขาที่ 1
  idCard?: string;
  address: string;
  subdistrict?: string;
  district?: string;
  province?: string;
  postalCode?: string;
  phone: string;
  email?: string;
}

export type ItemCategory = 'bicycle' | 'parts' | 'accessories' | 'service' | 'apparel' | 'custom';

export interface ProductItem {
  id: string;
  code: string;
  name: string;
  nameEn?: string;
  category: ItemCategory;
  price: number;
  unit: string;
  stock?: number;
  description?: string;
  serialRequired?: boolean;
}

export interface InvoiceItem {
  id: string;
  code: string;
  name: string;
  description?: string;
  serialNumber?: string; // Serial / Frame Number for Bicycles
  category: ItemCategory;
  quantity: number;
  unit: string;
  unitPrice: number;
  discountType: 'percent' | 'amount';
  discountValue: number;
  isVatExempt?: boolean;
  totalPrice: number; // calculated
}

export type PaymentMethod = 'cash' | 'promptpay' | 'transfer' | 'credit_card' | 'installment';

export interface PaymentDetails {
  method: PaymentMethod;
  bankName?: string;
  accountNumber?: string;
  creditCardRef?: string;
  installmentMonths?: number;
  paidAmount: number;
  changeAmount: number;
  paidAt: string;
  promptPayId: string;
}

export interface CompanyInfo {
  nameTh: string;
  nameEn: string;
  shortName: string;
  address: string;
  taxId: string;
  phone: string;
  email: string;
  website?: string;
  promptpayId: string;
  bankAccount: {
    bank: string;
    accountName: string;
    accountNumber: string;
    branch: string;
  };
}

export interface InvoiceDocument {
  id: string;
  documentNumber: string; // e.g., INV-202608-001
  type: DocumentType;
  issueDate: string; // YYYY-MM-DD
  dueDate?: string;  // YYYY-MM-DD
  referenceNumber?: string; // e.g. PO number or Quotation ref
  salesPerson: string;
  
  customer: Customer;
  items: InvoiceItem[];
  
  vatType: 'included' | 'excluded' | 'none'; // รวมภาษี / แยกภาษี / ยกเว้นภาษี
  vatRate: number; // e.g. 7 (%)
  withholdingTaxRate: number; // e.g. 0, 1, 3, 5 (%)
  
  overallDiscountType: 'percent' | 'amount';
  overallDiscountValue: number;
  
  // Computed values
  subtotal: number;
  itemDiscountTotal: number;
  overallDiscountAmount: number;
  netBeforeVat: number;
  vatAmount: number;
  withholdingTaxAmount: number;
  grandTotal: number;
  netPayable: number;
  bahtText: string;
  
  payment: PaymentDetails;
  status: 'draft' | 'issued' | 'paid' | 'cancelled';
  
  notes?: string;
  terms?: string;
  authorizedSignatureName: string;
  authorizedSignatureTitle: string;
  isSigned?: boolean;
  signatureDate?: string;
  copyType?: 'original' | 'copy';
}
