import React, { useState } from 'react';
import { InvoiceDocument } from '../types';
import { DALAYAR_COMPANY_INFO } from '../data/companyInfo';
import { formatCurrency } from '../utils/thaiBahtText';
import { 
  BarChart3, 
  TrendingUp, 
  Receipt, 
  Coins, 
  Percent, 
  Bike, 
  Wrench, 
  Download, 
  Calendar,
  Filter,
  FileSpreadsheet,
  CheckCircle2,
  Clock
} from 'lucide-react';

interface SalesDashboardProps {
  invoices: InvoiceDocument[];
  onOpenInvoice: (invoice: InvoiceDocument) => void;
}

export const SalesDashboard: React.FC<SalesDashboardProps> = ({
  invoices,
  onOpenInvoice,
}) => {
  const [selectedMonth, setSelectedMonth] = useState<string>('2026-08');

  // Filter invoices
  const filtered = invoices.filter(inv => inv.issueDate.startsWith(selectedMonth));

  // Compute metrics
  const totalSales = filtered.reduce((acc, inv) => acc + (inv.status !== 'cancelled' ? inv.grandTotal : 0), 0);
  const totalNetBeforeVat = filtered.reduce((acc, inv) => acc + (inv.status !== 'cancelled' ? inv.netBeforeVat : 0), 0);
  const totalVat = filtered.reduce((acc, inv) => acc + (inv.status !== 'cancelled' ? inv.vatAmount : 0), 0);
  const totalWithholding = filtered.reduce((acc, inv) => acc + (inv.status !== 'cancelled' ? inv.withholdingTaxAmount : 0), 0);

  // Bikes sold vs services
  let bikesSoldCount = 0;
  let serviceRevenue = 0;
  let partsRevenue = 0;

  filtered.forEach(inv => {
    if (inv.status !== 'cancelled') {
      inv.items.forEach(item => {
        if (item.category === 'bicycle') {
          bikesSoldCount += item.quantity;
        } else if (item.category === 'service') {
          serviceRevenue += item.totalPrice;
        } else {
          partsRevenue += item.totalPrice;
        }
      });
    }
  });

  const exportToCSV = () => {
    const headers = [
      'Document No',
      'Date',
      'Type',
      'Customer Name',
      'Customer Tax ID',
      'Net Before VAT',
      'VAT 7%',
      'Grand Total',
      'Payment Method',
      'Status'
    ];

    const rows = filtered.map(inv => [
      inv.documentNumber,
      inv.issueDate,
      inv.type,
      `"${inv.customer.name.replace(/"/g, '""')}"`,
      inv.customer.taxId || '-',
      inv.netBeforeVat.toFixed(2),
      inv.vatAmount.toFixed(2),
      inv.grandTotal.toFixed(2),
      inv.payment.method,
      inv.status
    ]);

    const csvContent = 'data:text/csv;charset=utf-8,\uFEFF' + 
      [headers.join(','), ...rows.map(e => e.join(','))].join('\n');
    
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `DALAYAR_TAX_REPORT_${selectedMonth}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="w-full max-w-7xl mx-auto space-y-6">
      
      {/* Header Bar */}
      <div className="bg-white p-5 rounded-2xl border border-stone-200 shadow-sm flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-lg font-bold text-stone-900 font-heading flex items-center gap-2">
            <BarChart3 className="w-5 h-5 text-amber-600" />
            รายงานภาษีขายและสรุปยอดขาย (SALES & TAX REPORT)
          </h2>
          <p className="text-xs text-stone-500 mt-0.5">
            สำหรับจัดทำรายงานภาษีขาย ภ.พ.30 ของ DALAYAR BICYCLE LIFESTYLE COMPANY (เลขผู้เสียภาษี: {DALAYAR_COMPANY_INFO.taxId})
          </p>
        </div>

        <div className="flex items-center gap-3">
          <div className="flex items-center gap-1.5 bg-stone-50 border border-stone-300 rounded-xl px-3 py-1.5 text-xs font-semibold">
            <Calendar className="w-4 h-4 text-stone-500" />
            <span>เดือน:</span>
            <input
              type="month"
              value={selectedMonth}
              onChange={(e) => setSelectedMonth(e.target.value)}
              className="bg-transparent border-none p-0 text-xs font-mono font-bold text-stone-900 focus:ring-0"
            />
          </div>

          <button
            onClick={exportToCSV}
            className="px-4 py-2 bg-stone-900 hover:bg-stone-800 text-white font-bold rounded-xl text-xs flex items-center gap-1.5 transition-all shadow-sm active:scale-95"
          >
            <FileSpreadsheet className="w-4 h-4 text-emerald-400" />
            ส่งออกไฟล์รายงาน CSV
          </button>
        </div>
      </div>

      {/* KPI Cards Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        
        {/* 1. Grand Total Revenue */}
        <div className="bg-white p-5 rounded-2xl border border-stone-200 shadow-sm space-y-2">
          <div className="flex items-center justify-between text-stone-500 text-xs font-semibold">
            <span>ยอดขายรวมทั้งสิ้น (Grand Total)</span>
            <div className="w-8 h-8 rounded-xl bg-amber-50 text-amber-700 flex items-center justify-center font-bold">
              <TrendingUp className="w-4 h-4" />
            </div>
          </div>
          <p className="font-mono text-2xl font-black text-stone-900">
            {formatCurrency(totalSales, true)}
          </p>
          <p className="text-[10px] text-stone-400">
            จากทั้งหมด {filtered.length} เอกสารในเดือนนี้
          </p>
        </div>

        {/* 2. Output VAT 7% */}
        <div className="bg-white p-5 rounded-2xl border border-stone-200 shadow-sm space-y-2">
          <div className="flex items-center justify-between text-stone-500 text-xs font-semibold">
            <span>ภาษีขาย Output VAT (7%)</span>
            <div className="w-8 h-8 rounded-xl bg-emerald-50 text-emerald-700 flex items-center justify-center font-bold">
              <Percent className="w-4 h-4" />
            </div>
          </div>
          <p className="font-mono text-2xl font-black text-emerald-700">
            {formatCurrency(totalVat, true)}
          </p>
          <p className="text-[10px] text-stone-500">
            ฐานภาษีมูลค่า: {formatCurrency(totalNetBeforeVat, true)}
          </p>
        </div>

        {/* 3. Bikes Sold Count */}
        <div className="bg-white p-5 rounded-2xl border border-stone-200 shadow-sm space-y-2">
          <div className="flex items-center justify-between text-stone-500 text-xs font-semibold">
            <span>จำนวนจักรยานที่จำหน่าย</span>
            <div className="w-8 h-8 rounded-xl bg-blue-50 text-blue-700 flex items-center justify-center font-bold">
              <Bike className="w-4 h-4" />
            </div>
          </div>
          <p className="font-mono text-2xl font-black text-stone-900">
            {bikesSoldCount} <span className="text-sm font-normal text-stone-500">คัน</span>
          </p>
          <p className="text-[10px] text-stone-400">
            ออกใบรับประกันและบันทึกเลขตัวถัง
          </p>
        </div>

        {/* 4. Workshop Service Revenue */}
        <div className="bg-white p-5 rounded-2xl border border-stone-200 shadow-sm space-y-2">
          <div className="flex items-center justify-between text-stone-500 text-xs font-semibold">
            <span>รายได้ค่าบริการช่าง & ฟิตติ้ง</span>
            <div className="w-8 h-8 rounded-xl bg-purple-50 text-purple-700 flex items-center justify-center font-bold">
              <Wrench className="w-4 h-4" />
            </div>
          </div>
          <p className="font-mono text-2xl font-black text-purple-700">
            {formatCurrency(serviceRevenue, true)}
          </p>
          <p className="text-[10px] text-stone-400">
            งานโอเวอร์ฮอล, ฟิตติ้ง, ไล่น้ำมันเบรก
          </p>
        </div>

      </div>

      {/* Tax Report Official Table */}
      <div className="bg-white rounded-2xl border border-stone-200 shadow-sm overflow-hidden space-y-4 p-5">
        <div className="flex items-center justify-between">
          <h3 className="text-sm font-bold text-stone-900 flex items-center gap-2">
            <Receipt className="w-4 h-4 text-amber-600" />
            ตารางรายงานภาษีขาย (ประจำเดือน {selectedMonth})
          </h3>
          <span className="text-xs text-stone-500">
            ภ.พ.30 พร้อมส่งสรรพากร
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="bg-stone-100 text-stone-700 font-semibold text-[11px] uppercase border-y border-stone-200">
                <th className="py-2.5 px-3">ลำดับ</th>
                <th className="py-2.5 px-3">วัน/เดือน/ปี</th>
                <th className="py-2.5 px-3">เลขที่ใบกำกับภาษี</th>
                <th className="py-2.5 px-3">ชื่อผู้ซื้อสินค้า/บริการ</th>
                <th className="py-2.5 px-3">เลขประจำตัวผู้เสียภาษี</th>
                <th className="py-2.5 px-3 text-right">มูลค่าสินค้า (฿)</th>
                <th className="py-2.5 px-3 text-right">ภาษีมูลค่าเพิ่ม 7% (฿)</th>
                <th className="py-2.5 px-3 text-right">จำนวนเงินรวม (฿)</th>
                <th className="py-2.5 px-3 text-center">สถานะ</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-stone-200">
              {filtered.length === 0 ? (
                <tr>
                  <td colSpan={9} className="py-8 text-center text-stone-400">
                    ไม่พบเอกสารในเดือนที่เลือก
                  </td>
                </tr>
              ) : (
                filtered.map((inv, idx) => (
                  <tr 
                    key={inv.id} 
                    onClick={() => onOpenInvoice(inv)}
                    className="hover:bg-amber-50/40 cursor-pointer transition-colors"
                  >
                    <td className="py-3 px-3 text-stone-500 font-mono">{idx + 1}</td>
                    <td className="py-3 px-3 font-medium text-stone-900">{inv.issueDate}</td>
                    <td className="py-3 px-3 font-mono font-bold text-stone-800">{inv.documentNumber}</td>
                    <td className="py-3 px-3">
                      <p className="font-semibold text-stone-900">{inv.customer.name}</p>
                      {inv.customer.branchType === 'branch' && (
                        <span className="text-[10px] text-stone-500">(สาขา {inv.customer.branchNumber})</span>
                      )}
                    </td>
                    <td className="py-3 px-3 font-mono text-stone-700 text-[11px]">
                      {inv.customer.taxId || inv.customer.idCard || '-'}
                    </td>
                    <td className="py-3 px-3 text-right font-mono font-medium text-stone-800">
                      {formatCurrency(inv.netBeforeVat, false)}
                    </td>
                    <td className="py-3 px-3 text-right font-mono font-semibold text-emerald-700">
                      {formatCurrency(inv.vatAmount, false)}
                    </td>
                    <td className="py-3 px-3 text-right font-mono font-bold text-stone-950">
                      {formatCurrency(inv.grandTotal, false)}
                    </td>
                    <td className="py-3 px-3 text-center">
                      <span className={`inline-block px-2 py-0.5 rounded text-[10px] font-bold uppercase ${
                        inv.status === 'paid' ? 'bg-emerald-100 text-emerald-800' :
                        inv.status === 'issued' ? 'bg-blue-100 text-blue-800' :
                        'bg-stone-100 text-stone-700'
                      }`}>
                        {inv.status === 'paid' ? 'ชำระแล้ว' : inv.status === 'issued' ? 'รอชำระ' : inv.status}
                      </span>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
            {filtered.length > 0 && (
              <tfoot>
                <tr className="bg-stone-900 text-white font-bold text-xs">
                  <td colSpan={5} className="py-3 px-3 text-right">ยอดรวมประจำเดือน:</td>
                  <td className="py-3 px-3 text-right font-mono text-stone-300">
                    {formatCurrency(totalNetBeforeVat, false)}
                  </td>
                  <td className="py-3 px-3 text-right font-mono text-emerald-400">
                    {formatCurrency(totalVat, false)}
                  </td>
                  <td className="py-3 px-3 text-right font-mono text-amber-400">
                    {formatCurrency(totalSales, false)}
                  </td>
                  <td></td>
                </tr>
              </tfoot>
            )}
          </table>
        </div>
      </div>

    </div>
  );
};
