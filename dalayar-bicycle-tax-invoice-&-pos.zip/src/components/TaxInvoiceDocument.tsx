import React, { useEffect, useState } from 'react';
import { InvoiceDocument } from '../types';
import { DALAYAR_COMPANY_INFO } from '../data/companyInfo';
import { formatCurrency } from '../utils/thaiBahtText';
import { generatePromptPayPayload, generateQrDataUrl } from '../utils/promptpay';
import { 
  Bike, 
  Printer, 
  Share2, 
  Download, 
  CheckCircle2, 
  QrCode, 
  Building2, 
  User, 
  Calendar, 
  Receipt,
  FileCheck,
  RotateCcw
} from 'lucide-react';

interface TaxInvoiceDocumentProps {
  invoice: InvoiceDocument;
  onEdit?: () => void;
  onPrintThermal?: () => void;
}

export const TaxInvoiceDocument: React.FC<TaxInvoiceDocumentProps> = ({
  invoice,
  onEdit,
  onPrintThermal,
}) => {
  const [copyType, setCopyType] = useState<'original' | 'copy'>('original');
  const [showStamp, setShowStamp] = useState<boolean>(true);
  const [qrDataUrl, setQrDataUrl] = useState<string>('');

  useEffect(() => {
    async function loadQr() {
      const amountToPay = invoice.netPayable || invoice.grandTotal;
      const payload = generatePromptPayPayload(DALAYAR_COMPANY_INFO.promptpayId, amountToPay);
      const url = await generateQrDataUrl(payload);
      setQrDataUrl(url);
    }
    loadQr();
  }, [invoice.grandTotal, invoice.netPayable]);

  const handlePrint = () => {
    window.print();
  };

  const getDocTypeHeader = (type: string) => {
    switch (type) {
      case 'TAX_INVOICE_RECEIPT':
        return {
          th: 'ใบกำกับภาษี / ใบเสร็จรับเงิน',
          en: 'TAX INVOICE / RECEIPT',
          subTh: '(เอกสารออกเป็นชุด)',
        };
      case 'TAX_INVOICE':
        return {
          th: 'ใบกำกับภาษี',
          en: 'TAX INVOICE',
          subTh: '',
        };
      case 'RECEIPT':
        return {
          th: 'ใบเสร็จรับเงิน',
          en: 'RECEIPT',
          subTh: '',
        };
      case 'QUOTATION':
        return {
          th: 'ใบเสนอราคา',
          en: 'QUOTATION / ESTIMATE',
          subTh: '',
        };
      case 'INVOICE':
        return {
          th: 'ใบแจ้งหนี้ / ใบวางบิล',
          en: 'INVOICE / BILLING NOTE',
          subTh: '',
        };
      case 'DELIVERY_NOTE':
        return {
          th: 'ใบส่งของ / ใบกำกับภาษี',
          en: 'DELIVERY ORDER / TAX INVOICE',
          subTh: '',
        };
      default:
        return {
          th: 'ใบกำกับภาษี / ใบเสร็จรับเงิน',
          en: 'TAX INVOICE / RECEIPT',
          subTh: '',
        };
    }
  };

  const docTitle = getDocTypeHeader(invoice.type);

  return (
    <div className="w-full max-w-4xl mx-auto space-y-4">
      {/* Control Bar (Screen Only) */}
      <div className="no-print bg-white p-3 sm:p-4 rounded-xl border border-stone-200 shadow-sm flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-2">
          <span className="text-xs font-semibold text-stone-600 uppercase tracking-wider">รูปแบบเอกสาร:</span>
          <div className="inline-flex rounded-lg bg-stone-100 p-1 border border-stone-200">
            <button
              onClick={() => setCopyType('original')}
              className={`px-3 py-1 text-xs font-medium rounded-md transition-all ${
                copyType === 'original'
                  ? 'bg-amber-500 text-stone-950 font-bold shadow-xs'
                  : 'text-stone-600 hover:text-stone-900'
              }`}
            >
              ต้นฉบับ (Original)
            </button>
            <button
              onClick={() => setCopyType('copy')}
              className={`px-3 py-1 text-xs font-medium rounded-md transition-all ${
                copyType === 'copy'
                  ? 'bg-amber-500 text-stone-950 font-bold shadow-xs'
                  : 'text-stone-600 hover:text-stone-900'
              }`}
            >
              สำเนา (Copy)
            </button>
          </div>

          <label className="flex items-center gap-1.5 ml-2 text-xs text-stone-700 cursor-pointer select-none">
            <input
              type="checkbox"
              checked={showStamp}
              onChange={(e) => setShowStamp(e.target.checked)}
              className="rounded text-amber-600 focus:ring-amber-500 border-stone-300 w-3.5 h-3.5"
            />
            <span>แสดงตราประทับร้าน</span>
          </label>
        </div>

        <div className="flex items-center gap-2">
          {onEdit && (
            <button
              onClick={onEdit}
              className="px-3 py-1.5 rounded-lg border border-stone-300 bg-white hover:bg-stone-50 text-stone-700 text-xs font-medium flex items-center gap-1.5 transition-all shadow-2xs"
            >
              <Receipt className="w-3.5 h-3.5 text-stone-500" />
              แก้ไขข้อมูล
            </button>
          )}

          {onPrintThermal && (
            <button
              onClick={onPrintThermal}
              className="px-3 py-1.5 rounded-lg border border-stone-300 bg-white hover:bg-stone-50 text-stone-700 text-xs font-medium flex items-center gap-1.5 transition-all shadow-2xs"
            >
              <Receipt className="w-3.5 h-3.5 text-amber-600" />
              พิมพ์สลิป 80mm
            </button>
          )}

          <button
            onClick={handlePrint}
            id="print-invoice-btn"
            className="px-4 py-1.5 rounded-lg bg-stone-900 hover:bg-stone-800 text-white text-xs font-semibold flex items-center gap-1.5 transition-all shadow-sm"
          >
            <Printer className="w-3.5 h-3.5 text-amber-400" />
            พิมพ์เอกสาร A4 (Print)
          </button>
        </div>
      </div>

      {/* A4 Tax Invoice Container */}
      <div 
        id="tax-invoice-a4-sheet"
        className="bg-white p-6 sm:p-10 rounded-2xl border border-stone-200/80 shadow-md font-sarabun text-stone-900 text-[13px] leading-relaxed relative print-container"
      >
        {/* Watermark Copy or Original */}
        <div className="absolute top-4 right-6 text-right">
          <span className={`inline-block px-3 py-1 rounded text-xs font-bold tracking-wider uppercase border ${
            copyType === 'original' 
              ? 'bg-amber-50 text-amber-900 border-amber-300' 
              : 'bg-stone-100 text-stone-700 border-stone-300'
          }`}>
            {copyType === 'original' ? 'ต้นฉบับ / ORIGINAL' : 'สำเนา / COPY'}
          </span>
          <p className="text-[10px] text-stone-400 mt-0.5">
            {copyType === 'original' ? '(สำหรับลูกค้า/ผู้ซื้อ)' : '(สำหรับผู้ออกเอกสาร/บัญชี)'}
          </p>
        </div>

        {/* 1. Header: Company Info + Document Title */}
        <div className="grid grid-cols-12 gap-4 pb-4 border-b-2 border-stone-800">
          
          {/* Left: Company Details */}
          <div className="col-span-8 space-y-1">
            <div className="flex items-center gap-2.5 mb-1">
              <div className="w-9 h-9 rounded-lg bg-stone-900 text-amber-400 flex items-center justify-center font-bold">
                <Bike className="w-5 h-5" />
              </div>
              <div>
                <h2 className="text-base font-bold text-stone-900 leading-tight">
                  {DALAYAR_COMPANY_INFO.nameTh}
                </h2>
                <p className="text-[11px] font-semibold text-stone-600 tracking-wide font-heading">
                  {DALAYAR_COMPANY_INFO.nameEn}
                </p>
              </div>
            </div>

            <div className="text-xs text-stone-700 space-y-0.5 pl-0.5">
              <p>
                <span className="font-semibold text-stone-900">ที่อยู่:</span> {DALAYAR_COMPANY_INFO.address}
              </p>
              <div className="flex flex-wrap gap-x-4 gap-y-0.5">
                <p>
                  <span className="font-semibold text-stone-900">เลขประจำตัวผู้เสียภาษีอากร:</span>{' '}
                  <span className="font-mono font-bold text-stone-950 bg-stone-100 px-1.5 py-0.5 rounded border border-stone-200">
                    {DALAYAR_COMPANY_INFO.taxId}
                  </span>
                </p>
                <p>
                  <span className="font-semibold text-stone-900">โทรศัพท์:</span> {DALAYAR_COMPANY_INFO.phone}
                </p>
              </div>
              <p className="text-stone-500 text-[11px]">
                <span>อีเมล: {DALAYAR_COMPANY_INFO.email}</span>
                <span className="mx-2">•</span>
                <span>เว็บไซต์: {DALAYAR_COMPANY_INFO.website}</span>
              </p>
            </div>
          </div>

          {/* Right: Document Title & Main Meta */}
          <div className="col-span-4 text-right pt-6 space-y-1">
            <h1 className="text-lg sm:text-xl font-extrabold text-stone-900 uppercase tracking-tight">
              {docTitle.th}
            </h1>
            <h3 className="text-xs font-bold text-amber-800 tracking-wider font-heading">
              {docTitle.en}
            </h3>
            {docTitle.subTh && (
              <p className="text-[10px] text-stone-500">{docTitle.subTh}</p>
            )}
          </div>
        </div>

        {/* 2. Customer Info & Invoice Meta Box */}
        <div className="grid grid-cols-12 gap-4 py-3.5 border-b border-stone-200 text-xs">
          
          {/* Customer Details */}
          <div className="col-span-7 pr-3 border-r border-stone-200 space-y-1">
            <div className="flex items-center gap-1.5 text-stone-500 font-semibold uppercase text-[11px] mb-1">
              <User className="w-3.5 h-3.5 text-amber-600" />
              <span>ข้อมูลลูกค้า / ผู้ซื้อ (CUSTOMER)</span>
            </div>

            <p className="text-sm font-bold text-stone-900">
              {invoice.customer.name || 'ลูกค้าทั่วไป (Walk-in Customer)'}
            </p>

            <p className="text-stone-700 leading-snug">
              <span className="font-semibold text-stone-800">ที่อยู่:</span>{' '}
              {invoice.customer.address || '-'}
            </p>

            <div className="flex flex-wrap gap-x-3 gap-y-0.5 pt-0.5 text-stone-800">
              {invoice.customer.taxId && (
                <p>
                  <span className="font-semibold">เลขประจำตัวผู้เสียภาษี:</span>{' '}
                  <span className="font-mono font-bold bg-stone-50 px-1 py-0.2 rounded border border-stone-200">
                    {invoice.customer.taxId}
                  </span>
                </p>
              )}

              {invoice.customer.type === 'company' && (
                <p>
                  <span className="font-semibold">สถานประกอบการ:</span>{' '}
                  {invoice.customer.branchType === 'head' 
                    ? 'สำนักงานใหญ่' 
                    : `สาขาที่ ${invoice.customer.branchNumber || '00001'}`}
                </p>
              )}

              {invoice.customer.idCard && !invoice.customer.taxId && (
                <p>
                  <span className="font-semibold">เลขบัตรประชาชน:</span> {invoice.customer.idCard}
                </p>
              )}

              {invoice.customer.phone && (
                <p>
                  <span className="font-semibold">โทร:</span> {invoice.customer.phone}
                </p>
              )}
            </div>
          </div>

          {/* Document Meta (Invoice Number, Date, PO, Salesperson) */}
          <div className="col-span-5 pl-2 space-y-1.5">
            <div className="flex justify-between items-center bg-stone-50 px-2.5 py-1 rounded border border-stone-200">
              <span className="font-semibold text-stone-700">เลขที่เอกสาร (Doc No.):</span>
              <span className="font-mono font-bold text-sm text-stone-950 tracking-wide">
                {invoice.documentNumber}
              </span>
            </div>

            <div className="flex justify-between items-center px-1">
              <span className="text-stone-600">วันที่ (Date):</span>
              <span className="font-semibold text-stone-900">{invoice.issueDate}</span>
            </div>

            {invoice.dueDate && (
              <div className="flex justify-between items-center px-1">
                <span className="text-stone-600">ครบกำหนด (Due Date):</span>
                <span className="font-semibold text-stone-900">{invoice.dueDate}</span>
              </div>
            )}

            {invoice.referenceNumber && (
              <div className="flex justify-between items-center px-1">
                <span className="text-stone-600">อ้างอิง (Ref No.):</span>
                <span className="font-mono text-stone-800">{invoice.referenceNumber}</span>
              </div>
            )}

            <div className="flex justify-between items-center px-1">
              <span className="text-stone-600">พนักงานขาย (Sales):</span>
              <span className="text-stone-800">{invoice.salesPerson || 'DALAYAR Staff'}</span>
            </div>
          </div>

        </div>

        {/* 3. Items Table */}
        <div className="py-3">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="bg-stone-900 text-white font-semibold text-[11px] uppercase tracking-wide">
                <th className="py-2 px-2 text-center rounded-l w-10">ลำดับ<br/>(No.)</th>
                <th className="py-2 px-2.5 w-24">รหัสสินค้า<br/>(Code)</th>
                <th className="py-2 px-3">รายการสินค้าและบริการ<br/>(Description)</th>
                <th className="py-2 px-2 text-center w-14">จำนวน<br/>(Qty)</th>
                <th className="py-2 px-2 text-center w-14">หน่วย<br/>(Unit)</th>
                <th className="py-2 px-3 text-right w-24">ราคา/หน่วย<br/>(Unit Price)</th>
                <th className="py-2 px-2 text-right w-20">ส่วนลด<br/>(Disc.)</th>
                <th className="py-2 px-3 text-right rounded-r w-28">จำนวนเงิน<br/>(Amount)</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-stone-200">
              {invoice.items.map((item, idx) => (
                <tr key={item.id || idx} className="hover:bg-stone-50/50">
                  <td className="py-2.5 px-2 text-center text-stone-500 font-mono">
                    {idx + 1}
                  </td>
                  <td className="py-2.5 px-2.5 font-mono text-stone-700 text-[11px]">
                    {item.code || '-'}
                  </td>
                  <td className="py-2.5 px-3">
                    <p className="font-semibold text-stone-900 leading-tight">
                      {item.name}
                    </p>
                    {item.description && (
                      <p className="text-[11px] text-stone-500 mt-0.5 leading-snug">
                        {item.description}
                      </p>
                    )}
                    {item.serialNumber && (
                      <div className="mt-1 inline-flex items-center gap-1 px-1.5 py-0.5 rounded bg-amber-50 border border-amber-200 text-amber-900 text-[10px] font-mono">
                        <span className="font-bold">หมายเลขเฟรม/Serial:</span>
                        <span>{item.serialNumber}</span>
                      </div>
                    )}
                  </td>
                  <td className="py-2.5 px-2 text-center font-mono font-medium text-stone-800">
                    {item.quantity}
                  </td>
                  <td className="py-2.5 px-2 text-center text-stone-600">
                    {item.unit || 'ชิ้น'}
                  </td>
                  <td className="py-2.5 px-3 text-right font-mono text-stone-800">
                    {formatCurrency(item.unitPrice, false)}
                  </td>
                  <td className="py-2.5 px-2 text-right font-mono text-stone-600">
                    {item.discountValue > 0 
                      ? `${item.discountValue}${item.discountType === 'percent' ? '%' : ''}`
                      : '-'}
                  </td>
                  <td className="py-2.5 px-3 text-right font-mono font-semibold text-stone-900">
                    {formatCurrency(item.totalPrice, false)}
                  </td>
                </tr>
              ))}

              {/* Minimum rows padding for pristine official form appearance */}
              {invoice.items.length < 4 && Array.from({ length: 4 - invoice.items.length }).map((_, i) => (
                <tr key={`empty-${i}`} className="opacity-20 border-b border-dashed border-stone-200">
                  <td className="py-2.5 px-2 text-center">&nbsp;</td>
                  <td className="py-2.5 px-2.5">&nbsp;</td>
                  <td className="py-2.5 px-3 text-stone-400 text-[11px]">-</td>
                  <td className="py-2.5 px-2">&nbsp;</td>
                  <td className="py-2.5 px-2">&nbsp;</td>
                  <td className="py-2.5 px-3">&nbsp;</td>
                  <td className="py-2.5 px-2">&nbsp;</td>
                  <td className="py-2.5 px-3">&nbsp;</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* 4. Calculation & Summary Section */}
        <div className="grid grid-cols-12 gap-4 pt-2 border-t-2 border-stone-800">
          
          {/* Left: Thai Baht Text + QR Payment + Bank info */}
          <div className="col-span-7 space-y-3">
            
            {/* Thai Baht text banner */}
            <div className="bg-stone-50 p-2.5 rounded-lg border border-stone-200">
              <span className="text-[10px] text-stone-500 uppercase font-semibold block">
                จำนวนเงินตัวอักษร (TOTAL IN WORDS)
              </span>
              <p className="text-xs font-bold text-stone-900 mt-0.5">
                ({invoice.bahtText})
              </p>
            </div>

            {/* Payment & PromptPay details */}
            <div className="flex items-start gap-3 bg-stone-50/80 p-2.5 rounded-lg border border-stone-200 text-xs">
              {qrDataUrl && (
                <div className="shrink-0 text-center bg-white p-1 rounded border border-stone-200 shadow-2xs">
                  <img 
                    src={qrDataUrl} 
                    alt="PromptPay QR Code" 
                    className="w-20 h-20 object-contain mx-auto" 
                    referrerPolicy="no-referrer"
                  />
                  <span className="text-[9px] font-bold text-blue-900 block font-mono">
                    พร้อมเพย์ PromptPay
                  </span>
                </div>
              )}
              <div className="space-y-1 text-stone-700 text-[11px] leading-tight">
                <p className="font-bold text-stone-900 flex items-center gap-1">
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                  การชำระเงิน (PAYMENT):
                </p>
                <p>
                  <span className="font-semibold">ช่องทาง:</span>{' '}
                  {invoice.payment.method === 'promptpay' && 'พร้อมเพย์ QR Code (PromptPay)'}
                  {invoice.payment.method === 'transfer' && 'โอนเงินผ่านบัญชีธนาคาร'}
                  {invoice.payment.method === 'cash' && 'เงินสด (Cash)'}
                  {invoice.payment.method === 'credit_card' && 'บัตรเครดิต/เดบิต'}
                  {invoice.payment.method === 'installment' && 'ผ่อนชำระ'}
                </p>
                <p>
                  <span className="font-semibold">บัญชี:</span> {DALAYAR_COMPANY_INFO.bankAccount.bank}
                </p>
                <p>
                  <span className="font-semibold">เลขที่:</span>{' '}
                  <span className="font-mono font-bold text-stone-900">
                    {DALAYAR_COMPANY_INFO.bankAccount.accountNumber}
                  </span>
                </p>
                <p className="text-stone-500">
                  ชื่อบัญชี: {DALAYAR_COMPANY_INFO.bankAccount.accountName}
                </p>
              </div>
            </div>

            {/* Notes & Terms */}
            {(invoice.notes || invoice.terms) && (
              <div className="text-[11px] text-stone-600 space-y-0.5 pl-0.5">
                {invoice.notes && (
                  <p>
                    <span className="font-semibold text-stone-800">หมายเหตุ (Notes):</span> {invoice.notes}
                  </p>
                )}
                {invoice.terms && (
                  <p className="text-[10px] text-stone-500">
                    <span className="font-semibold">เงื่อนไข:</span> {invoice.terms}
                  </p>
                )}
              </div>
            )}
          </div>

          {/* Right: Tax Breakdown */}
          <div className="col-span-5 space-y-1 text-xs">
            
            <div className="flex justify-between py-1 border-b border-stone-100 text-stone-700">
              <span>รวมเป็นเงิน (Subtotal):</span>
              <span className="font-mono font-medium">{formatCurrency(invoice.subtotal, false)}</span>
            </div>

            {(invoice.itemDiscountTotal > 0 || invoice.overallDiscountAmount > 0) && (
              <div className="flex justify-between py-1 border-b border-stone-100 text-rose-600">
                <span>ส่วนลดรวม (Total Discount):</span>
                <span className="font-mono font-medium">
                  -{formatCurrency((invoice.itemDiscountTotal || 0) + (invoice.overallDiscountAmount || 0), false)}
                </span>
              </div>
            )}

            <div className="flex justify-between py-1 border-b border-stone-100 text-stone-700">
              <span>
                {invoice.vatType === 'included' 
                  ? 'มูลค่าสินค้า/บริการ (ก่อน VAT):' 
                  : 'มูลค่าสินค้าที่เสียภาษี:'}
              </span>
              <span className="font-mono font-medium">{formatCurrency(invoice.netBeforeVat, false)}</span>
            </div>

            <div className="flex justify-between py-1 border-b border-stone-100 text-stone-700">
              <span>ภาษีมูลค่าเพิ่ม VAT {invoice.vatRate}%:</span>
              <span className="font-mono font-medium">{formatCurrency(invoice.vatAmount, false)}</span>
            </div>

            {invoice.withholdingTaxAmount > 0 && (
              <div className="flex justify-between py-1 border-b border-stone-100 text-amber-700">
                <span>หักภาษี ณ ที่จ่าย ({invoice.withholdingTaxRate}%):</span>
                <span className="font-mono font-medium">
                  -{formatCurrency(invoice.withholdingTaxAmount, false)}
                </span>
              </div>
            )}

            <div className="flex justify-between items-center py-2 px-2.5 bg-stone-900 text-white rounded-lg font-bold mt-2">
              <span className="text-xs">จำนวนเงินรวมทั้งสิ้น (Grand Total):</span>
              <span className="font-mono text-sm sm:text-base text-amber-400">
                {formatCurrency(invoice.netPayable || invoice.grandTotal, true)}
              </span>
            </div>

            {invoice.payment.paidAmount > 0 && (
              <div className="flex justify-between text-[11px] text-stone-500 pt-1 px-1">
                <span>ยอดชำระแล้ว: {formatCurrency(invoice.payment.paidAmount, true)}</span>
                {invoice.payment.changeAmount > 0 && (
                  <span>เงินทอน: {formatCurrency(invoice.payment.changeAmount, true)}</span>
                )}
              </div>
            )}
          </div>

        </div>

        {/* 5. Signatures and Stamp Section */}
        <div className="grid grid-cols-2 gap-8 pt-8 mt-6 border-t border-stone-200 text-xs relative">
          
          {/* Company Stamp if active */}
          {showStamp && (
            <div className="absolute left-1/2 -top-3 -translate-x-1/2 pointer-events-none opacity-85 select-none rotate-[-6deg]">
              <div className="w-28 h-28 rounded-full border-2 border-red-600/70 p-1 flex items-center justify-center text-center">
                <div className="w-full h-full rounded-full border border-dashed border-red-500/80 flex flex-col items-center justify-center p-2 text-red-600">
                  <Bike className="w-4 h-4 mb-0.5" />
                  <span className="text-[9px] font-extrabold tracking-tighter leading-none">DALAYAR BICYCLE</span>
                  <span className="text-[8px] font-medium leading-tight">ดาลาญาร์ ไลฟ์สไตล์</span>
                  <span className="text-[7px] font-mono mt-0.5">1401701236251</span>
                </div>
              </div>
            </div>
          )}

          {/* Customer Signature Box */}
          <div className="text-center space-y-8 p-3 border border-stone-200 rounded-lg bg-stone-50/50">
            <p className="text-stone-700 font-medium">
              ผู้รับสินค้า / บริการ (Customer Signature)
            </p>
            <div className="space-y-1.5 pt-4">
              <div className="w-48 mx-auto border-b border-stone-400 border-dotted"></div>
              <p className="text-stone-800 font-semibold">
                ( {invoice.customer.name || '...................................................'} )
              </p>
              <p className="text-[11px] text-stone-500">
                วันที่ (Date): {invoice.issueDate || '........ / ........ / ................'}
              </p>
            </div>
          </div>

          {/* Authorized Company Signature Box */}
          <div className="text-center space-y-8 p-3 border border-stone-200 rounded-lg bg-stone-50/50">
            <p className="text-stone-700 font-medium">
              ผู้มีอำนาจลงนาม / ผู้รับเงิน (Authorized Signature)
            </p>
            <div className="space-y-1.5 pt-4">
              <div className="w-48 mx-auto border-b border-stone-400 border-dotted relative">
                {invoice.isSigned && (
                  <span className="absolute bottom-1 left-1/2 -translate-x-1/2 font-serif italic text-base font-bold text-blue-900 tracking-wider">
                    Darayar D.
                  </span>
                )}
              </div>
              <p className="text-stone-900 font-bold">
                ( {invoice.authorizedSignatureName || 'ดาราญาร์ ดิษฐ์'} )
              </p>
              <p className="text-[11px] text-stone-600">
                {invoice.authorizedSignatureTitle || 'ผู้จัดการ / กรรมการผู้จัดการ'}
              </p>
              <p className="text-[10px] text-stone-500">
                วันที่: {invoice.signatureDate || invoice.issueDate}
              </p>
            </div>
          </div>

        </div>

        {/* Bottom micro note */}
        <div className="text-center text-[10px] text-stone-400 pt-6 mt-4 border-t border-stone-100">
          เอกสารนี้ออกโดยระบบอัตโนมัติ DALAYAR BICYCLE LIFESTYLE COMPANY • ถูกต้องตามประมวลรัษฎากร มาตรา 86/4
        </div>
      </div>
    </div>
  );
};
