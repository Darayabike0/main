import React, { useState } from 'react';
import { InvoiceDocument, DocumentType } from '../types';
import { formatCurrency } from '../utils/thaiBahtText';
import { 
  FileText, 
  Search, 
  Plus, 
  Eye, 
  Printer, 
  Edit3, 
  Trash2, 
  Copy, 
  CheckCircle2, 
  Clock, 
  AlertCircle,
  Receipt,
  FileSpreadsheet,
  Bike
} from 'lucide-react';

interface InvoiceListProps {
  invoices: InvoiceDocument[];
  onOpenInvoice: (invoice: InvoiceDocument) => void;
  onEditInvoice: (invoice: InvoiceDocument) => void;
  onPrintSlip: (invoice: InvoiceDocument) => void;
  onDeleteInvoice: (id: string) => void;
  onDuplicateInvoice: (invoice: InvoiceDocument) => void;
  onNewInvoice: () => void;
}

export const InvoiceList: React.FC<InvoiceListProps> = ({
  invoices,
  onOpenInvoice,
  onEditInvoice,
  onPrintSlip,
  onDeleteInvoice,
  onDuplicateInvoice,
  onNewInvoice,
}) => {
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [filterType, setFilterType] = useState<string>('all');
  const [filterStatus, setFilterStatus] = useState<string>('all');

  const filtered = invoices.filter(inv => {
    const matchesSearch = inv.documentNumber.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          inv.customer.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          (inv.customer.taxId && inv.customer.taxId.includes(searchQuery)) ||
                          inv.items.some(i => i.name.toLowerCase().includes(searchQuery.toLowerCase()));
    
    const matchesType = filterType === 'all' || inv.type === filterType;
    const matchesStatus = filterStatus === 'all' || inv.status === filterStatus;

    return matchesSearch && matchesType && matchesStatus;
  });

  const getDocTypeLabel = (type: DocumentType) => {
    switch (type) {
      case 'TAX_INVOICE_RECEIPT': return 'ใบกำกับภาษี/ใบเสร็จ';
      case 'TAX_INVOICE': return 'ใบกำกับภาษี';
      case 'RECEIPT': return 'ใบเสร็จรับเงิน';
      case 'QUOTATION': return 'ใบเสนอราคา';
      case 'INVOICE': return 'ใบแจ้งหนี้/วางบิล';
      case 'DELIVERY_NOTE': return 'ใบส่งของ';
      default: return type;
    }
  };

  return (
    <div className="w-full max-w-7xl mx-auto space-y-6">
      
      {/* Header Bar */}
      <div className="bg-white p-5 rounded-2xl border border-stone-200 shadow-sm flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-lg font-bold text-stone-900 font-heading flex items-center gap-2">
            <FileText className="w-5 h-5 text-amber-600" />
            รายการเอกสารภาษี / ใบเสร็จรับเงิน (INVOICE ARCHIVE)
          </h2>
          <p className="text-xs text-stone-500 mt-0.5">
            จัดการและพิมพ์ใบกำกับภาษี, ใบเสนอราคา, ใบแจ้งหนี้ และสลิปการขายหน้าร้าน
          </p>
        </div>

        <button
          onClick={onNewInvoice}
          id="list-create-invoice-btn"
          className="px-4 py-2 bg-amber-500 hover:bg-amber-400 text-stone-950 font-bold rounded-xl text-xs flex items-center gap-1.5 transition-all shadow-sm active:scale-95 self-start sm:self-auto"
        >
          <Plus className="w-4 h-4" />
          สร้างเอกสารใหม่
        </button>
      </div>

      {/* Filter and Search Bar */}
      <div className="bg-white p-4 rounded-2xl border border-stone-200 shadow-sm flex flex-col md:flex-row gap-3 items-center justify-between">
        
        {/* Search */}
        <div className="relative w-full md:w-80">
          <Search className="w-4 h-4 text-stone-400 absolute left-3 top-2.5" />
          <input
            type="text"
            placeholder="ค้นหาเลขที่เอกสาร, ชื่อลูกค้า, เลขผู้เสียภาษี..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-9 pr-3 py-2 text-xs bg-stone-50 border border-stone-300 rounded-xl"
          />
        </div>

        {/* Filter Controls */}
        <div className="flex flex-wrap gap-2 w-full md:w-auto">
          
          <select
            value={filterType}
            onChange={(e) => setFilterType(e.target.value)}
            className="text-xs bg-stone-50 border border-stone-300 rounded-xl px-3 py-2 font-medium"
          >
            <option value="all">ทุกประเภทเอกสาร</option>
            <option value="TAX_INVOICE_RECEIPT">ใบกำกับภาษี / ใบเสร็จรับเงิน</option>
            <option value="TAX_INVOICE">ใบกำกับภาษี</option>
            <option value="RECEIPT">ใบเสร็จรับเงิน</option>
            <option value="QUOTATION">ใบเสนอราคา</option>
            <option value="INVOICE">ใบแจ้งหนี้ / วางบิล</option>
            <option value="DELIVERY_NOTE">ใบส่งของ</option>
          </select>

          <select
            value={filterStatus}
            onChange={(e) => setFilterStatus(e.target.value)}
            className="text-xs bg-stone-50 border border-stone-300 rounded-xl px-3 py-2 font-medium"
          >
            <option value="all">ทุกสถานะ</option>
            <option value="paid">ชำระแล้ว (Paid)</option>
            <option value="issued">รอชำระ (Pending)</option>
            <option value="draft">ฉบับร่าง (Draft)</option>
            <option value="cancelled">ยกเลิก (Cancelled)</option>
          </select>

        </div>

      </div>

      {/* Invoice Table */}
      <div className="bg-white rounded-2xl border border-stone-200 shadow-sm overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="bg-stone-100 text-stone-700 font-semibold text-[11px] uppercase border-b border-stone-200">
                <th className="py-3 px-3 w-28">เลขที่เอกสาร</th>
                <th className="py-3 px-3 w-24">วันที่</th>
                <th className="py-3 px-3 w-32">ประเภท</th>
                <th className="py-3 px-3">ลูกค้า / บริษัทผู้ซื้อ</th>
                <th className="py-3 px-3 text-right w-24">ภาษี 7%</th>
                <th className="py-3 px-3 text-right w-28">ยอดสุทธิ</th>
                <th className="py-3 px-3 w-24 text-center">สถานะ</th>
                <th className="py-3 px-3 w-36 text-center">การจัดการ</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-stone-200">
              {filtered.length === 0 ? (
                <tr>
                  <td colSpan={8} className="py-12 text-center text-stone-400 space-y-2">
                    <FileText className="w-8 h-8 mx-auto text-stone-300 stroke-1" />
                    <p>ไม่พบเอกสารตามเงื่อนไขที่ค้นหา</p>
                  </td>
                </tr>
              ) : (
                filtered.map((inv) => (
                  <tr 
                    key={inv.id} 
                    className="hover:bg-stone-50/80 transition-colors group"
                  >
                    <td className="py-3.5 px-3 font-mono font-bold text-stone-900">
                      <button
                        onClick={() => onOpenInvoice(inv)}
                        className="hover:text-amber-600 hover:underline flex items-center gap-1"
                      >
                        {inv.documentNumber}
                      </button>
                    </td>

                    <td className="py-3.5 px-3 text-stone-600 font-medium">
                      {inv.issueDate}
                    </td>

                    <td className="py-3.5 px-3">
                      <span className="inline-block px-2 py-0.5 rounded-full text-[10px] font-semibold bg-stone-100 text-stone-700">
                        {getDocTypeLabel(inv.type)}
                      </span>
                    </td>

                    <td className="py-3.5 px-3 space-y-0.5">
                      <p className="font-bold text-stone-900">
                        {inv.customer.name}
                      </p>
                      {inv.customer.taxId && (
                        <p className="text-[10px] text-stone-500 font-mono">
                          Tax ID: {inv.customer.taxId}
                        </p>
                      )}
                      <p className="text-[10px] text-stone-400 line-clamp-1">
                        {inv.items.map(i => i.name).join(', ')}
                      </p>
                    </td>

                    <td className="py-3.5 px-3 text-right font-mono text-stone-600">
                      {formatCurrency(inv.vatAmount, false)}
                    </td>

                    <td className="py-3.5 px-3 text-right font-mono font-bold text-stone-900 text-sm">
                      {formatCurrency(inv.netPayable || inv.grandTotal, true)}
                    </td>

                    <td className="py-3.5 px-3 text-center">
                      <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold ${
                        inv.status === 'paid' ? 'bg-emerald-50 text-emerald-700 border border-emerald-200' :
                        inv.status === 'issued' ? 'bg-blue-50 text-blue-700 border border-blue-200' :
                        'bg-stone-100 text-stone-600 border border-stone-200'
                      }`}>
                        {inv.status === 'paid' && <CheckCircle2 className="w-3 h-3" />}
                        {inv.status === 'issued' && <Clock className="w-3 h-3" />}
                        {inv.status === 'paid' ? 'ชำระแล้ว' : inv.status === 'issued' ? 'รอชำระ' : inv.status}
                      </span>
                    </td>

                    <td className="py-3.5 px-3 text-center">
                      <div className="flex items-center justify-center gap-1">
                        <button
                          onClick={() => onOpenInvoice(inv)}
                          title="ดูและพิมพ์เอกสาร A4"
                          className="p-1.5 text-stone-600 hover:text-amber-600 hover:bg-stone-100 rounded-lg transition-colors"
                        >
                          <Eye className="w-4 h-4" />
                        </button>
                        <button
                          onClick={() => onPrintSlip(inv)}
                          title="พิมพ์สลิป 80mm"
                          className="p-1.5 text-stone-600 hover:text-amber-600 hover:bg-stone-100 rounded-lg transition-colors"
                        >
                          <Receipt className="w-4 h-4" />
                        </button>
                        <button
                          onClick={() => onEditInvoice(inv)}
                          title="แก้ไขเอกสาร"
                          className="p-1.5 text-stone-600 hover:text-amber-600 hover:bg-stone-100 rounded-lg transition-colors"
                        >
                          <Edit3 className="w-4 h-4" />
                        </button>
                        <button
                          onClick={() => onDuplicateInvoice(inv)}
                          title="ทำซ้ำเอกสาร"
                          className="p-1.5 text-stone-400 hover:text-stone-700 hover:bg-stone-100 rounded-lg transition-colors"
                        >
                          <Copy className="w-4 h-4" />
                        </button>
                        <button
                          onClick={() => onDeleteInvoice(inv.id)}
                          title="ลบเอกสาร"
                          className="p-1.5 text-stone-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-colors"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

    </div>
  );
};
