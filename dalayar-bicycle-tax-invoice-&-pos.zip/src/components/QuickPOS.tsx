import React, { useState, useEffect } from 'react';
import { 
  ProductItem, 
  InvoiceItem, 
  Customer, 
  InvoiceDocument,
  PaymentMethod 
} from '../types';
import { DALAYAR_COMPANY_INFO } from '../data/companyInfo';
import { calculateInvoiceTotals } from '../utils/taxCalculator';
import { formatCurrency } from '../utils/thaiBahtText';
import { generatePromptPayPayload, generateQrDataUrl } from '../utils/promptpay';
import confetti from 'canvas-confetti';
import { 
  ShoppingBag, 
  Bike, 
  Wrench, 
  Package, 
  Plus, 
  Minus, 
  Trash2, 
  Search, 
  QrCode, 
  CreditCard, 
  Banknote, 
  Printer, 
  CheckCircle2, 
  X,
  User,
  ArrowRight,
  Sparkles
} from 'lucide-react';

interface QuickPOSProps {
  catalog: ProductItem[];
  customers: Customer[];
  onCompleteSale: (invoice: InvoiceDocument) => void;
  onOpenDocument: (invoice: InvoiceDocument) => void;
  onOpenSlip: (invoice: InvoiceDocument) => void;
}

export const QuickPOS: React.FC<QuickPOSProps> = ({
  catalog,
  customers,
  onCompleteSale,
  onOpenDocument,
  onOpenSlip,
}) => {
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');
  
  // Cart items
  const [cart, setCart] = useState<InvoiceItem[]>([]);
  
  // Customer
  const [selectedCustomerId, setSelectedCustomerId] = useState<string>(customers[0]?.id || '');
  const [selectedCustomer, setSelectedCustomer] = useState<Customer>(customers[0] || {
    id: 'walkin',
    type: 'individual',
    name: 'ลูกค้าทั่วไป (Walk-in)',
    address: 'หน้าร้าน DALAYAR มัญจาคีรี ขอนแก่น',
    phone: '084-014-8961',
  });

  // Checkout modal
  const [checkoutModalOpen, setCheckoutModalOpen] = useState<boolean>(false);
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>('promptpay');
  const [cashReceived, setCashReceived] = useState<number>(0);
  const [qrUrl, setQrUrl] = useState<string>('');
  const [completedDoc, setCompletedDoc] = useState<InvoiceDocument | null>(null);

  // Cart calculations
  const totals = calculateInvoiceTotals(cart, 'included', 7, 0, 'amount', 0);

  // Handle category filter
  const filteredProducts = catalog.filter(p => {
    const matchesCat = selectedCategory === 'all' || p.category === selectedCategory;
    const matchesQuery = p.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         p.code.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCat && matchesQuery;
  });

  const addToCart = (product: ProductItem) => {
    const existingIndex = cart.findIndex(item => item.code === product.code);
    if (existingIndex > -1) {
      const updated = [...cart];
      updated[existingIndex].quantity += 1;
      updated[existingIndex].totalPrice = (updated[existingIndex].quantity * updated[existingIndex].unitPrice);
      setCart(updated);
    } else {
      const newItem: InvoiceItem = {
        id: `cart-${Date.now()}-${Math.random()}`,
        code: product.code,
        name: product.name,
        description: product.description,
        serialNumber: product.serialRequired ? `DLR-${product.code.split('-')[1] || 'BIKE'}-${new Date().getFullYear()}-${Math.floor(Math.random() * 8999 + 1000)}` : undefined,
        category: product.category,
        quantity: 1,
        unit: product.unit,
        unitPrice: product.price,
        discountType: 'amount',
        discountValue: 0,
        totalPrice: product.price,
      };
      setCart([...cart, newItem]);
    }
  };

  const updateCartQuantity = (index: number, delta: number) => {
    const updated = [...cart];
    const newQty = updated[index].quantity + delta;
    if (newQty <= 0) {
      setCart(cart.filter((_, i) => i !== index));
    } else {
      updated[index].quantity = newQty;
      updated[index].totalPrice = (newQty * updated[index].unitPrice);
      setCart(updated);
    }
  };

  const removeFromCart = (index: number) => {
    setCart(cart.filter((_, i) => i !== index));
  };

  const clearCart = () => {
    setCart([]);
  };

  // Open Checkout
  const handleOpenCheckout = async () => {
    if (cart.length === 0) return;
    const finalAmount = totals.grandTotal;
    setCashReceived(finalAmount);
    
    // Generate QR
    const payload = generatePromptPayPayload(DALAYAR_COMPANY_INFO.promptpayId, finalAmount);
    const url = await generateQrDataUrl(payload);
    setQrUrl(url);
    
    setCheckoutModalOpen(true);
  };

  const handleCustomerChange = (custId: string) => {
    setSelectedCustomerId(custId);
    const found = customers.find(c => c.id === custId);
    if (found) {
      setSelectedCustomer(found);
    }
  };

  // Finalize Transaction
  const handleConfirmPayment = () => {
    const today = new Date();
    const yyyymm = `${today.getFullYear()}${String(today.getMonth() + 1).padStart(2, '0')}`;
    const randomSeq = String(Math.floor(Math.random() * 900) + 100);
    const docNumber = `TAX-${yyyymm}-${randomSeq}`;
    
    const finalAmount = totals.netPayable || totals.grandTotal;
    const change = Math.max(0, cashReceived - finalAmount);

    const doc: InvoiceDocument = {
      id: `inv-${Date.now()}`,
      documentNumber: docNumber,
      type: 'TAX_INVOICE_RECEIPT',
      issueDate: today.toISOString().split('T')[0],
      dueDate: today.toISOString().split('T')[0],
      salesPerson: 'แคชเชียร์หน้าร้าน (DALAYAR Counter)',
      customer: selectedCustomer,
      items: [...cart],
      vatType: 'included',
      vatRate: 7,
      withholdingTaxRate: 0,
      overallDiscountType: 'amount',
      overallDiscountValue: 0,
      subtotal: totals.subtotal,
      itemDiscountTotal: totals.itemDiscountTotal,
      overallDiscountAmount: totals.overallDiscountAmount,
      netBeforeVat: totals.netBeforeVat,
      vatAmount: totals.vatAmount,
      withholdingTaxAmount: 0,
      grandTotal: totals.grandTotal,
      netPayable: totals.netPayable,
      bahtText: totals.bahtText,
      payment: {
        method: paymentMethod,
        paidAmount: cashReceived >= finalAmount ? cashReceived : finalAmount,
        changeAmount: change,
        paidAt: `${today.toISOString().split('T')[0]} ${today.toTimeString().split(' ')[0].substring(0, 5)}`,
        promptPayId: DALAYAR_COMPANY_INFO.promptpayId,
      },
      status: 'paid',
      notes: 'รับประกันเฟรมจักรยาน 5 ปี, เช็คระบบฟรี 3 เดือนแรก',
      terms: 'ใบเสร็จรับเงิน/ใบกำกับภาษีถูกต้องตามกฎหมาย',
      authorizedSignatureName: 'ดาราญาร์ ดิษฐ์ (ผู้มีอำนาจลงนาม)',
      authorizedSignatureTitle: 'กรรมการผู้จัดการ',
      isSigned: true,
      signatureDate: today.toISOString().split('T')[0],
      copyType: 'original',
    };

    onCompleteSale(doc);
    setCompletedDoc(doc);
    
    // Confetti effect
    try {
      confetti({
        particleCount: 80,
        spread: 60,
        origin: { y: 0.6 }
      });
    } catch (e) {
      // ignore
    }
  };

  const handleFinishAndReset = () => {
    setCart([]);
    setCheckoutModalOpen(false);
    setCompletedDoc(null);
  };

  return (
    <div className="w-full max-w-7xl mx-auto grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
      
      {/* Left side: Product Catalog Grid (7 cols) */}
      <div className="lg:col-span-7 space-y-4">
        
        {/* Category Tabs & Search Bar */}
        <div className="bg-white p-4 rounded-2xl border border-stone-200 shadow-sm space-y-3">
          
          <div className="relative">
            <Search className="w-4 h-4 text-stone-400 absolute left-3.5 top-3" />
            <input
              type="text"
              placeholder="ค้นหาจักรยาน, อะไหล่, อุปกรณ์ หรือบริการซ่อม..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-10 pr-4 py-2.5 bg-stone-50 border border-stone-300 rounded-xl text-xs sm:text-sm focus:ring-2 focus:ring-amber-500"
            />
          </div>

          <div className="flex flex-wrap gap-1.5 pt-1">
            {[
              { id: 'all', label: 'ทั้งหมด', icon: Package },
              { id: 'bicycle', label: '🚲 รถจักรยาน', icon: Bike },
              { id: 'parts', label: '⚙️ อะไหล่ & ชุดขับ', icon: Package },
              { id: 'accessories', label: '🎒 อุปกรณ์ & แต่งรถ', icon: Package },
              { id: 'service', label: '🔧 งานบริการช่าง', icon: Wrench },
            ].map(cat => (
              <button
                key={cat.id}
                onClick={() => setSelectedCategory(cat.id)}
                className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition-all ${
                  selectedCategory === cat.id
                    ? 'bg-amber-500 text-stone-950 shadow-xs'
                    : 'bg-stone-100 hover:bg-stone-200 text-stone-700'
                }`}
              >
                {cat.label}
              </button>
            ))}
          </div>
        </div>

        {/* Product Cards Grid */}
        <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 max-h-[680px] overflow-y-auto pr-1">
          {filteredProducts.map(product => {
            const inCart = cart.find(i => i.code === product.code);
            return (
              <div
                key={product.id}
                onClick={() => addToCart(product)}
                className={`group bg-white p-3.5 rounded-2xl border transition-all cursor-pointer flex flex-col justify-between hover:shadow-md select-none relative ${
                  inCart ? 'border-amber-400 ring-2 ring-amber-400/20 bg-amber-50/20' : 'border-stone-200 hover:border-amber-300'
                }`}
              >
                {inCart && (
                  <div className="absolute top-2 right-2 w-5 h-5 rounded-full bg-amber-500 text-stone-950 text-[10px] font-extrabold flex items-center justify-center shadow-xs">
                    {inCart.quantity}
                  </div>
                )}

                <div className="space-y-1.5">
                  <div className="flex items-center gap-1.5">
                    <span className="text-[10px] font-mono font-bold px-1.5 py-0.2 rounded bg-stone-100 text-stone-600">
                      {product.code}
                    </span>
                    <span className="text-[9px] uppercase font-bold text-amber-700">
                      {product.category === 'bicycle' ? 'BIKE' : product.category === 'service' ? 'SERVICE' : 'ITEM'}
                    </span>
                  </div>

                  <h4 className="text-xs font-bold text-stone-900 group-hover:text-amber-900 line-clamp-2 leading-snug">
                    {product.name}
                  </h4>

                  {product.description && (
                    <p className="text-[10px] text-stone-500 line-clamp-2 leading-tight">
                      {product.description}
                    </p>
                  )}
                </div>

                <div className="pt-3 mt-2 border-t border-stone-100 flex items-baseline justify-between">
                  <span className="font-mono text-sm font-extrabold text-stone-900 group-hover:text-amber-600">
                    {formatCurrency(product.price, true)}
                  </span>
                  <span className="text-[10px] text-stone-400">/{product.unit}</span>
                </div>
              </div>
            );
          })}
        </div>

      </div>

      {/* Right side: Shopping Cart & Instant Checkout (5 cols) */}
      <div className="lg:col-span-5 bg-white rounded-2xl border border-stone-200 shadow-lg p-5 space-y-4 sticky top-20">
        
        {/* Cart Header */}
        <div className="flex items-center justify-between pb-3 border-b border-stone-200">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-amber-500 text-stone-950 flex items-center justify-center font-bold">
              <ShoppingBag className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-stone-900">
                รายการชำระเงินหน้าร้าน
              </h3>
              <p className="text-[10px] text-stone-500">DALAYAR POS TERMINAL</p>
            </div>
          </div>

          {cart.length > 0 && (
            <button
              onClick={clearCart}
              className="text-[11px] text-stone-400 hover:text-rose-600 flex items-center gap-1 transition-colors"
            >
              <Trash2 className="w-3 h-3" />
              ล้างตะกร้า
            </button>
          )}
        </div>

        {/* Customer selector */}
        <div className="bg-stone-50 p-2.5 rounded-xl border border-stone-200 space-y-1">
          <label className="text-[11px] font-semibold text-stone-700 flex items-center gap-1">
            <User className="w-3 h-3 text-amber-600" />
            เลือกลูกค้าสำหรับออกใบกำกับภาษี:
          </label>
          <select
            value={selectedCustomerId}
            onChange={(e) => handleCustomerChange(e.target.value)}
            className="w-full text-xs font-medium bg-white border border-stone-300 rounded-lg px-2.5 py-1.5"
          >
            {customers.map(c => (
              <option key={c.id} value={c.id}>
                {c.type === 'company' ? '🏢 [นิติบุคคล] ' : '👤 '}
                {c.name} {c.taxId ? `(${c.taxId})` : ''}
              </option>
            ))}
          </select>
        </div>

        {/* Cart Item list */}
        <div className="space-y-2 max-h-[300px] overflow-y-auto pr-1">
          {cart.length === 0 ? (
            <div className="py-12 text-center text-stone-400 space-y-2">
              <ShoppingBag className="w-10 h-10 mx-auto text-stone-300 stroke-1" />
              <p className="text-xs font-medium">ยังไม่มีรายการสินค้าในตะกร้า</p>
              <p className="text-[10px] text-stone-400">แตะที่การ์ดสินค้าทางซ้ายเพื่อเพิ่มรายการ</p>
            </div>
          ) : (
            cart.map((item, idx) => (
              <div
                key={item.id || idx}
                className="p-2.5 bg-stone-50/80 rounded-xl border border-stone-200/80 flex items-center justify-between gap-2 text-xs"
              >
                <div className="flex-1 space-y-0.5 min-w-0">
                  <p className="font-bold text-stone-900 truncate">
                    {item.name}
                  </p>
                  <p className="text-[10px] text-stone-500 font-mono">
                    {formatCurrency(item.unitPrice, true)} / {item.unit}
                  </p>
                  {item.serialNumber && (
                    <p className="text-[9px] font-mono text-amber-800">
                      SN: {item.serialNumber}
                    </p>
                  )}
                </div>

                <div className="flex items-center gap-1.5 shrink-0">
                  <button
                    onClick={() => updateCartQuantity(idx, -1)}
                    className="w-6 h-6 rounded-lg bg-white border border-stone-300 hover:bg-stone-100 flex items-center justify-center text-stone-700 font-bold"
                  >
                    <Minus className="w-3 h-3" />
                  </button>
                  <span className="w-6 text-center font-mono font-bold text-xs text-stone-900">
                    {item.quantity}
                  </span>
                  <button
                    onClick={() => updateCartQuantity(idx, 1)}
                    className="w-6 h-6 rounded-lg bg-white border border-stone-300 hover:bg-stone-100 flex items-center justify-center text-stone-700 font-bold"
                  >
                    <Plus className="w-3 h-3" />
                  </button>
                </div>

                <div className="text-right shrink-0 min-w-[65px]">
                  <span className="font-mono font-bold text-stone-900">
                    {formatCurrency(item.totalPrice, false)}
                  </span>
                </div>
              </div>
            ))
          )}
        </div>

        {/* Calculation summary */}
        {cart.length > 0 && (
          <div className="pt-3 border-t border-stone-200 space-y-1.5 text-xs">
            <div className="flex justify-between text-stone-600">
              <span>ราคารวมสินค้า:</span>
              <span className="font-mono">{formatCurrency(totals.subtotal, false)}</span>
            </div>
            <div className="flex justify-between text-stone-500 text-[11px]">
              <span>มูลค่าก่อน VAT:</span>
              <span className="font-mono">{formatCurrency(totals.netBeforeVat, false)}</span>
            </div>
            <div className="flex justify-between text-stone-500 text-[11px]">
              <span>ภาษีมูลค่าเพิ่ม (VAT 7%):</span>
              <span className="font-mono text-amber-700">{formatCurrency(totals.vatAmount, false)}</span>
            </div>

            <div className="pt-2 border-t border-stone-200 flex justify-between items-baseline">
              <span className="font-bold text-stone-900 text-sm">ยอดชำระสุทธิ:</span>
              <span className="font-mono text-xl font-black text-amber-600">
                {formatCurrency(totals.grandTotal, true)}
              </span>
            </div>
            <p className="text-[10px] text-stone-500 text-right">({totals.bahtText})</p>

            <button
              onClick={handleOpenCheckout}
              id="pos-checkout-btn"
              className="w-full mt-3 py-3 bg-amber-500 hover:bg-amber-400 text-stone-950 font-bold rounded-xl text-sm transition-all shadow-md shadow-amber-900/20 flex items-center justify-center gap-2 active:scale-98"
            >
              <QrCode className="w-4 h-4" />
              รับชำระเงิน & ออกใบกำกับภาษี
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        )}

      </div>

      {/* Checkout Modal */}
      {checkoutModalOpen && (
        <div className="fixed inset-0 z-50 bg-stone-950/75 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-lg w-full p-6 shadow-2xl border border-stone-200 space-y-4">
            
            {!completedDoc ? (
              <>
                <div className="flex items-center justify-between pb-3 border-b border-stone-200">
                  <div className="flex items-center gap-2">
                    <div className="w-8 h-8 rounded-xl bg-amber-500 text-stone-950 flex items-center justify-center font-bold">
                      <QrCode className="w-4 h-4" />
                    </div>
                    <div>
                      <h3 className="text-base font-bold text-stone-900">
                        ชำระเงิน (DALAYAR CHECKOUT)
                      </h3>
                      <p className="text-[11px] text-stone-500">ยอดชำระ: {formatCurrency(totals.grandTotal, true)}</p>
                    </div>
                  </div>
                  <button
                    onClick={() => setCheckoutModalOpen(false)}
                    className="p-1 text-stone-400 hover:text-stone-700 rounded-lg hover:bg-stone-100"
                  >
                    <X className="w-5 h-5" />
                  </button>
                </div>

                {/* Payment Method Selector */}
                <div className="grid grid-cols-3 gap-2">
                  <button
                    type="button"
                    onClick={() => setPaymentMethod('promptpay')}
                    className={`p-2.5 rounded-xl border text-xs font-bold flex flex-col items-center gap-1 transition-all ${
                      paymentMethod === 'promptpay' ? 'bg-amber-500 text-stone-950 border-amber-500 shadow-sm' : 'bg-stone-50 text-stone-700'
                    }`}
                  >
                    <QrCode className="w-4 h-4" />
                    <span>พร้อมเพย์ QR</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => setPaymentMethod('cash')}
                    className={`p-2.5 rounded-xl border text-xs font-bold flex flex-col items-center gap-1 transition-all ${
                      paymentMethod === 'cash' ? 'bg-amber-500 text-stone-950 border-amber-500 shadow-sm' : 'bg-stone-50 text-stone-700'
                    }`}
                  >
                    <Banknote className="w-4 h-4" />
                    <span>เงินสด (Cash)</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => setPaymentMethod('transfer')}
                    className={`p-2.5 rounded-xl border text-xs font-bold flex flex-col items-center gap-1 transition-all ${
                      paymentMethod === 'transfer' ? 'bg-amber-500 text-stone-950 border-amber-500 shadow-sm' : 'bg-stone-50 text-stone-700'
                    }`}
                  >
                    <CreditCard className="w-4 h-4" />
                    <span>โอนเงิน/บัตร</span>
                  </button>
                </div>

                {/* PromptPay QR Display */}
                {paymentMethod === 'promptpay' && qrUrl && (
                  <div className="bg-stone-50 p-4 rounded-xl border border-stone-200 text-center space-y-2">
                    <img
                      src={qrUrl}
                      alt="PromptPay QR Code"
                      className="w-44 h-44 mx-auto rounded-lg border border-stone-300 p-1 bg-white shadow-xs"
                      referrerPolicy="no-referrer"
                    />
                    <div>
                      <p className="text-xs font-bold text-stone-900">
                        พร้อมเพย์: {DALAYAR_COMPANY_INFO.promptpayId}
                      </p>
                      <p className="text-[10px] text-stone-500">
                        {DALAYAR_COMPANY_INFO.nameTh}
                      </p>
                      <p className="text-xs font-mono font-bold text-amber-700 mt-1">
                        ยอดสแกนจ่าย: {formatCurrency(totals.grandTotal, true)}
                      </p>
                    </div>
                  </div>
                )}

                {/* Cash Quick Buttons */}
                {paymentMethod === 'cash' && (
                  <div className="space-y-3 bg-stone-50 p-4 rounded-xl border border-stone-200">
                    <div className="flex items-center justify-between text-xs">
                      <span className="font-semibold text-stone-700">รับเงินสดมา (฿):</span>
                      <input
                        type="number"
                        value={cashReceived}
                        onChange={(e) => setCashReceived(Number(e.target.value))}
                        className="w-32 text-right font-mono font-bold text-sm bg-white border border-stone-300 rounded-lg px-2.5 py-1"
                      />
                    </div>

                    <div className="flex flex-wrap gap-1.5">
                      {[totals.grandTotal, 100, 500, 1000, 5000, 10000, 50000].map(val => (
                        <button
                          key={val}
                          type="button"
                          onClick={() => setCashReceived(val)}
                          className="px-2.5 py-1 bg-white hover:bg-stone-200 border border-stone-300 rounded-lg text-xs font-mono font-semibold text-stone-700"
                        >
                          {val === totals.grandTotal ? 'พอดี' : `฿${val.toLocaleString()}`}
                        </button>
                      ))}
                    </div>

                    {cashReceived >= totals.grandTotal && (
                      <div className="p-2.5 bg-emerald-50 rounded-lg border border-emerald-200 flex justify-between items-center text-xs font-bold text-emerald-800">
                        <span>เงินทอน (Change):</span>
                        <span className="font-mono text-base">
                          {formatCurrency(cashReceived - totals.grandTotal, true)}
                        </span>
                      </div>
                    )}
                  </div>
                )}

                <button
                  type="button"
                  onClick={handleConfirmPayment}
                  id="confirm-payment-btn"
                  className="w-full py-3 bg-stone-900 hover:bg-stone-800 text-white font-bold rounded-xl text-sm transition-all shadow-md flex items-center justify-center gap-2"
                >
                  <CheckCircle2 className="w-4 h-4 text-amber-400" />
                  ยืนยันการรับชำระเงินและออกบิล
                </button>
              </>
            ) : (
              /* Success Screen */
              <div className="text-center py-4 space-y-4">
                <div className="w-14 h-14 rounded-full bg-emerald-100 text-emerald-600 mx-auto flex items-center justify-center">
                  <CheckCircle2 className="w-8 h-8" />
                </div>
                <div>
                  <h3 className="text-lg font-bold text-stone-900 font-heading">
                    บันทึกการขายสำเร็จ!
                  </h3>
                  <p className="text-xs font-mono text-stone-500 mt-0.5">
                    เลขที่เอกสาร: <span className="font-bold text-stone-800">{completedDoc.documentNumber}</span>
                  </p>
                  <p className="text-sm font-bold text-amber-600 mt-1">
                    ยอดรับชำระ: {formatCurrency(completedDoc.grandTotal, true)}
                  </p>
                </div>

                <div className="grid grid-cols-2 gap-2 pt-2">
                  <button
                    onClick={() => onOpenSlip(completedDoc)}
                    className="py-2.5 px-3 bg-stone-100 hover:bg-stone-200 text-stone-800 rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 transition-all"
                  >
                    <Printer className="w-4 h-4 text-stone-600" />
                    พิมพ์สลิป 80mm
                  </button>

                  <button
                    onClick={() => onOpenDocument(completedDoc)}
                    className="py-2.5 px-3 bg-stone-900 hover:bg-stone-800 text-white rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 transition-all"
                  >
                    <Printer className="w-4 h-4 text-amber-400" />
                    พิมพ์ใบกำกับภาษี A4
                  </button>
                </div>

                <button
                  onClick={handleFinishAndReset}
                  className="w-full py-2.5 bg-amber-500 hover:bg-amber-400 text-stone-950 font-bold rounded-xl text-xs transition-all"
                >
                  เริ่มการขายรายการถัดไป
                </button>
              </div>
            )}

          </div>
        </div>
      )}

    </div>
  );
};
