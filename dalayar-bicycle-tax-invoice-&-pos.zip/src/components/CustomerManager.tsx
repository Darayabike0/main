import React, { useState } from 'react';
import { Customer, CustomerType } from '../types';
import { 
  Users, 
  Building2, 
  User, 
  Plus, 
  Search, 
  Edit3, 
  Trash2, 
  FileText,
  Phone,
  Mail,
  MapPin,
  X
} from 'lucide-react';

interface CustomerManagerProps {
  customers: Customer[];
  onAddCustomer: (customer: Customer) => void;
  onUpdateCustomer: (customer: Customer) => void;
  onDeleteCustomer: (id: string) => void;
  onCreateInvoiceForCustomer: (customer: Customer) => void;
}

export const CustomerManager: React.FC<CustomerManagerProps> = ({
  customers,
  onAddCustomer,
  onUpdateCustomer,
  onDeleteCustomer,
  onCreateInvoiceForCustomer,
}) => {
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [filterType, setFilterType] = useState<string>('all');
  
  const [modalOpen, setModalOpen] = useState<boolean>(false);
  const [editingCustomer, setEditingCustomer] = useState<Customer | null>(null);

  // Form
  const [type, setType] = useState<CustomerType>('company');
  const [name, setName] = useState<string>('');
  const [taxId, setTaxId] = useState<string>('');
  const [branchType, setBranchType] = useState<'head' | 'branch'>('head');
  const [branchNumber, setBranchNumber] = useState<string>('00000');
  const [idCard, setIdCard] = useState<string>('');
  const [address, setAddress] = useState<string>('');
  const [phone, setPhone] = useState<string>('');
  const [email, setEmail] = useState<string>('');

  const openAddModal = () => {
    setEditingCustomer(null);
    setType('company');
    setName('');
    setTaxId('');
    setBranchType('head');
    setBranchNumber('00000');
    setIdCard('');
    setAddress('ตำบลมัญจาคีรี อำเภอมัญจาคีรี จังหวัดขอนแก่น 40160');
    setPhone('');
    setEmail('');
    setModalOpen(true);
  };

  const openEditModal = (c: Customer) => {
    setEditingCustomer(c);
    setType(c.type);
    setName(c.name);
    setTaxId(c.taxId || '');
    setBranchType(c.branchType || 'head');
    setBranchNumber(c.branchNumber || '00000');
    setIdCard(c.idCard || '');
    setAddress(c.address || '');
    setPhone(c.phone || '');
    setEmail(c.email || '');
    setModalOpen(true);
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    if (editingCustomer) {
      onUpdateCustomer({
        ...editingCustomer,
        type,
        name,
        taxId: type === 'company' ? taxId : undefined,
        branchType: type === 'company' ? branchType : undefined,
        branchNumber: type === 'company' && branchType === 'branch' ? branchNumber : undefined,
        idCard: type === 'individual' ? (idCard || taxId) : undefined,
        address,
        phone,
        email,
      });
    } else {
      onAddCustomer({
        id: `cust-${Date.now()}`,
        type,
        name,
        taxId: type === 'company' ? taxId : undefined,
        branchType: type === 'company' ? branchType : undefined,
        branchNumber: type === 'company' && branchType === 'branch' ? branchNumber : undefined,
        idCard: type === 'individual' ? (idCard || taxId) : undefined,
        address,
        phone,
        email,
      });
    }
    setModalOpen(false);
  };

  const filtered = customers.filter(c => {
    const matchesType = filterType === 'all' || c.type === filterType;
    const matchesSearch = c.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          (c.taxId && c.taxId.includes(searchQuery)) ||
                          (c.phone && c.phone.includes(searchQuery));
    return matchesType && matchesSearch;
  });

  return (
    <div className="w-full max-w-7xl mx-auto space-y-6">
      
      {/* Header */}
      <div className="bg-white p-5 rounded-2xl border border-stone-200 shadow-sm flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-lg font-bold text-stone-900 font-heading flex items-center gap-2">
            <Users className="w-5 h-5 text-amber-600" />
            สมุดรายชื่อลูกค้า / ผู้ซื้อ (CUSTOMER DIRECTORY)
          </h2>
          <p className="text-xs text-stone-500 mt-0.5">
            จัดการข้อมูลลูกค้าบุคคลและนิติบุคคลสำหรับออกใบกำกับภาษีเต็มรูป
          </p>
        </div>

        <button
          onClick={openAddModal}
          id="add-customer-btn"
          className="px-4 py-2 bg-amber-500 hover:bg-amber-400 text-stone-950 font-bold rounded-xl text-xs flex items-center gap-1.5 transition-all shadow-sm active:scale-95 self-start sm:self-auto"
        >
          <Plus className="w-4 h-4" />
          เพิ่มลูกค้าใหม่
        </button>
      </div>

      {/* Filter and Search */}
      <div className="bg-white p-4 rounded-2xl border border-stone-200 shadow-sm flex flex-col md:flex-row gap-3 items-center justify-between">
        <div className="relative w-full md:w-80">
          <Search className="w-4 h-4 text-stone-400 absolute left-3 top-2.5" />
          <input
            type="text"
            placeholder="ค้นหาชื่อลูกค้า, เลขผู้เสียภาษี 13 หลัก, เบอร์โทร..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-9 pr-3 py-2 text-xs bg-stone-50 border border-stone-300 rounded-xl"
          />
        </div>

        <div className="flex gap-2">
          <button
            onClick={() => setFilterType('all')}
            className={`px-3 py-1.5 rounded-xl text-xs font-semibold ${
              filterType === 'all' ? 'bg-stone-900 text-amber-400' : 'bg-stone-100 text-stone-700'
            }`}
          >
            ทุกลูกค้า ({customers.length})
          </button>
          <button
            onClick={() => setFilterType('company')}
            className={`px-3 py-1.5 rounded-xl text-xs font-semibold ${
              filterType === 'company' ? 'bg-stone-900 text-amber-400' : 'bg-stone-100 text-stone-700'
            }`}
          >
            🏢 นิติบุคคล / องค์กร ({customers.filter(c => c.type === 'company').length})
          </button>
          <button
            onClick={() => setFilterType('individual')}
            className={`px-3 py-1.5 rounded-xl text-xs font-semibold ${
              filterType === 'individual' ? 'bg-stone-900 text-amber-400' : 'bg-stone-100 text-stone-700'
            }`}
          >
            👤 ลูกค้าบุคคล ({customers.filter(c => c.type === 'individual').length})
          </button>
        </div>
      </div>

      {/* Customer Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {filtered.map(cust => (
          <div
            key={cust.id}
            className="bg-white p-5 rounded-2xl border border-stone-200 shadow-sm hover:border-amber-400 transition-all flex flex-col justify-between space-y-3 group"
          >
            <div className="space-y-2">
              <div className="flex items-start justify-between gap-2">
                <div className="flex items-center gap-2">
                  <div className={`w-8 h-8 rounded-xl flex items-center justify-center font-bold text-xs ${
                    cust.type === 'company' ? 'bg-blue-50 text-blue-700 border border-blue-200' : 'bg-amber-50 text-amber-800 border border-amber-200'
                  }`}>
                    {cust.type === 'company' ? <Building2 className="w-4 h-4" /> : <User className="w-4 h-4" />}
                  </div>
                  <div>
                    <h3 className="font-bold text-stone-900 text-sm group-hover:text-amber-900">
                      {cust.name}
                    </h3>
                    <span className="text-[10px] text-stone-400 uppercase font-medium">
                      {cust.type === 'company' ? 'นิติบุคคล (Corporate Client)' : 'บุคคลธรรมดา (Individual Cyclist)'}
                    </span>
                  </div>
                </div>

                <div className="flex items-center gap-1">
                  <button
                    onClick={() => openEditModal(cust)}
                    className="p-1.5 text-stone-400 hover:text-amber-600 hover:bg-stone-100 rounded-lg transition-colors"
                  >
                    <Edit3 className="w-3.5 h-3.5" />
                  </button>
                  <button
                    onClick={() => onDeleteCustomer(cust.id)}
                    className="p-1.5 text-stone-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-colors"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>

              {/* Meta details */}
              <div className="text-xs text-stone-600 space-y-1 pt-1">
                {cust.taxId && (
                  <p className="flex items-center gap-1.5">
                    <span className="font-semibold text-stone-800">เลขผู้เสียภาษี:</span>
                    <span className="font-mono font-bold bg-stone-100 px-1.5 py-0.2 rounded border border-stone-200 text-stone-900">
                      {cust.taxId}
                    </span>
                    {cust.type === 'company' && (
                      <span className="text-[10px] text-stone-500">
                        ({cust.branchType === 'head' ? 'สนง.ใหญ่' : `สาขา ${cust.branchNumber}`})
                      </span>
                    )}
                  </p>
                )}

                {cust.address && (
                  <p className="flex items-start gap-1.5 text-stone-600 leading-snug">
                    <MapPin className="w-3.5 h-3.5 text-stone-400 shrink-0 mt-0.5" />
                    <span>{cust.address}</span>
                  </p>
                )}

                <div className="flex flex-wrap gap-x-4 gap-y-1 text-stone-500 pt-1">
                  {cust.phone && (
                    <span className="flex items-center gap-1 font-mono text-[11px]">
                      <Phone className="w-3 h-3 text-stone-400" />
                      {cust.phone}
                    </span>
                  )}
                  {cust.email && (
                    <span className="flex items-center gap-1 text-[11px]">
                      <Mail className="w-3 h-3 text-stone-400" />
                      {cust.email}
                    </span>
                  )}
                </div>
              </div>
            </div>

            {/* Quick create invoice button */}
            <div className="pt-3 border-t border-stone-100 flex justify-end">
              <button
                onClick={() => onCreateInvoiceForCustomer(cust)}
                className="px-3 py-1.5 bg-stone-900 hover:bg-stone-800 text-white rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-all shadow-xs"
              >
                <FileText className="w-3.5 h-3.5 text-amber-400" />
                ออกใบกำกับภาษีให้ลูกค้ารายนี้
              </button>
            </div>
          </div>
        ))}
      </div>

      {/* Customer Modal */}
      {modalOpen && (
        <div className="fixed inset-0 z-50 bg-stone-950/70 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-lg w-full p-6 shadow-2xl border border-stone-200 space-y-4">
            
            <div className="flex items-center justify-between pb-3 border-b border-stone-200">
              <h3 className="text-base font-bold text-stone-900 font-heading">
                {editingCustomer ? 'แก้ไขข้อมูลลูกค้า' : 'เพิ่มข้อมูลลูกค้าใหม่'}
              </h3>
              <button
                onClick={() => setModalOpen(false)}
                className="p-1 text-stone-400 hover:text-stone-700 rounded-lg"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSave} className="space-y-4 text-xs">
              
              <div>
                <label className="block font-semibold text-stone-700 mb-1">ประเภทลูกค้า</label>
                <div className="flex rounded-xl bg-stone-100 p-1 border border-stone-200">
                  <button
                    type="button"
                    onClick={() => setType('company')}
                    className={`flex-1 py-1.5 text-xs font-semibold rounded-lg transition-all ${
                      type === 'company' ? 'bg-white text-stone-900 shadow-xs' : 'text-stone-600'
                    }`}
                  >
                    🏢 นิติบุคคล / บริษัท
                  </button>
                  <button
                    type="button"
                    onClick={() => setType('individual')}
                    className={`flex-1 py-1.5 text-xs font-semibold rounded-lg transition-all ${
                      type === 'individual' ? 'bg-white text-stone-900 shadow-xs' : 'text-stone-600'
                    }`}
                  >
                    👤 บุคคลธรรมดา
                  </button>
                </div>
              </div>

              <div>
                <label className="block font-semibold text-stone-700 mb-1">
                  ชื่อ-นามสกุล / ชื่อบริษัท <span className="text-rose-500">*</span>
                </label>
                <input
                  type="text"
                  required
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="เช่น บจก. ขอนแก่น แอดเวนเจอร์"
                  className="w-full bg-stone-50 border border-stone-300 rounded-xl px-3 py-2 font-medium"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className={type === 'company' ? 'col-span-1' : 'col-span-2'}>
                  <label className="block font-semibold text-stone-700 mb-1">
                    {type === 'company' ? 'เลขประจำตัวผู้เสียภาษี 13 หลัก' : 'เลขบัตรประชาชน / Tax ID'}
                  </label>
                  <input
                    type="text"
                    maxLength={13}
                    value={taxId}
                    onChange={(e) => setTaxId(e.target.value)}
                    placeholder="13 หลัก เช่น 0405562001892"
                    className="w-full bg-stone-50 border border-stone-300 rounded-xl px-3 py-2 font-mono font-bold"
                  />
                </div>

                {type === 'company' && (
                  <div>
                    <label className="block font-semibold text-stone-700 mb-1">สถานประกอบการ</label>
                    <div className="flex gap-2">
                      <select
                        value={branchType}
                        onChange={(e) => setBranchType(e.target.value as any)}
                        className="w-1/2 bg-stone-50 border border-stone-300 rounded-xl px-2 py-2"
                      >
                        <option value="head">สำนักงานใหญ่</option>
                        <option value="branch">สาขา</option>
                      </select>
                      {branchType === 'branch' && (
                        <input
                          type="text"
                          placeholder="00001"
                          value={branchNumber}
                          onChange={(e) => setBranchNumber(e.target.value)}
                          className="w-1/2 bg-stone-50 border border-stone-300 rounded-xl px-2 py-2 font-mono"
                        />
                      )}
                    </div>
                  </div>
                )}
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block font-semibold text-stone-700 mb-1">เบอร์โทรศัพท์</label>
                  <input
                    type="text"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    placeholder="08X-XXX-XXXX"
                    className="w-full bg-stone-50 border border-stone-300 rounded-xl px-3 py-2 font-mono"
                  />
                </div>

                <div>
                  <label className="block font-semibold text-stone-700 mb-1">อีเมล</label>
                  <input
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="customer@email.com"
                    className="w-full bg-stone-50 border border-stone-300 rounded-xl px-3 py-2"
                  />
                </div>
              </div>

              <div>
                <label className="block font-semibold text-stone-700 mb-1">ที่อยู่จดทะเบียนภาษี / ที่อยู่จัดส่ง</label>
                <textarea
                  rows={2}
                  value={address}
                  onChange={(e) => setAddress(e.target.value)}
                  placeholder="เลขที่ ถนน ตำบล อำเภอ จังหวัด รหัสไปรษณีย์"
                  className="w-full bg-stone-50 border border-stone-300 rounded-xl p-2"
                />
              </div>

              <div className="pt-3 border-t border-stone-200 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setModalOpen(false)}
                  className="px-4 py-2 rounded-xl border border-stone-300 text-xs font-semibold text-stone-700 hover:bg-stone-50"
                >
                  ยกเลิก
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-stone-950 text-xs font-bold shadow-xs"
                >
                  บันทึกข้อมูลลูกค้า
                </button>
              </div>
            </form>

          </div>
        </div>
      )}

    </div>
  );
};
