import React, { useState } from 'react';
import { ProductItem, ItemCategory } from '../types';
import { formatCurrency } from '../utils/thaiBahtText';
import { 
  Package, 
  Bike, 
  Wrench, 
  Plus, 
  Search, 
  Edit3, 
  Trash2, 
  Check, 
  X,
  Tag,
  Layers
} from 'lucide-react';

interface CatalogManagerProps {
  catalog: ProductItem[];
  onAddProduct: (product: ProductItem) => void;
  onUpdateProduct: (product: ProductItem) => void;
  onDeleteProduct: (id: string) => void;
}

export const CatalogManager: React.FC<CatalogManagerProps> = ({
  catalog,
  onAddProduct,
  onUpdateProduct,
  onDeleteProduct,
}) => {
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');
  
  // Modal state
  const [modalOpen, setModalOpen] = useState<boolean>(false);
  const [editingProduct, setEditingProduct] = useState<ProductItem | null>(null);

  // Form state
  const [code, setCode] = useState<string>('');
  const [name, setName] = useState<string>('');
  const [nameEn, setNameEn] = useState<string>('');
  const [category, setCategory] = useState<ItemCategory>('bicycle');
  const [price, setPrice] = useState<number>(1000);
  const [unit, setUnit] = useState<string>('คัน');
  const [stock, setStock] = useState<number>(5);
  const [description, setDescription] = useState<string>('');
  const [serialRequired, setSerialRequired] = useState<boolean>(true);

  const openAddModal = () => {
    setEditingProduct(null);
    setCode(`BK-${Math.floor(Math.random() * 899 + 100)}`);
    setName('');
    setNameEn('');
    setCategory('bicycle');
    setPrice(15000);
    setUnit('คัน');
    setStock(3);
    setDescription('');
    setSerialRequired(true);
    setModalOpen(true);
  };

  const openEditModal = (prod: ProductItem) => {
    setEditingProduct(prod);
    setCode(prod.code);
    setName(prod.name);
    setNameEn(prod.nameEn || '');
    setCategory(prod.category);
    setPrice(prod.price);
    setUnit(prod.unit);
    setStock(prod.stock ?? 0);
    setDescription(prod.description || '');
    setSerialRequired(!!prod.serialRequired);
    setModalOpen(true);
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    if (editingProduct) {
      onUpdateProduct({
        ...editingProduct,
        code,
        name,
        nameEn,
        category,
        price,
        unit,
        stock: category === 'service' ? undefined : stock,
        description,
        serialRequired,
      });
    } else {
      onAddProduct({
        id: `prod-${Date.now()}`,
        code,
        name,
        nameEn,
        category,
        price,
        unit,
        stock: category === 'service' ? undefined : stock,
        description,
        serialRequired,
      });
    }
    setModalOpen(false);
  };

  const filtered = catalog.filter(p => {
    const matchesCat = selectedCategory === 'all' || p.category === selectedCategory;
    const matchesSearch = p.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          p.code.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCat && matchesSearch;
  });

  return (
    <div className="w-full max-w-7xl mx-auto space-y-6">
      
      {/* Header Bar */}
      <div className="bg-white p-5 rounded-2xl border border-stone-200 shadow-sm flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-lg font-bold text-stone-900 font-heading flex items-center gap-2">
            <Package className="w-5 h-5 text-amber-600" />
            คลังสินค้าและบริการจักรยาน (DALAYAR CATALOG)
          </h2>
          <p className="text-xs text-stone-500 mt-0.5">
            จัดการรายการรถจักรยาน, อะไหล่, อุปกรณ์ตกแต่ง และอัตราค่าบริการช่าง
          </p>
        </div>

        <button
          onClick={openAddModal}
          id="add-product-btn"
          className="px-4 py-2 bg-amber-500 hover:bg-amber-400 text-stone-950 font-bold rounded-xl text-xs flex items-center gap-1.5 transition-all shadow-sm active:scale-95 self-start sm:self-auto"
        >
          <Plus className="w-4 h-4" />
          เพิ่มรายการสินค้า/บริการใหม่
        </button>
      </div>

      {/* Filter & Search Controls */}
      <div className="bg-white p-4 rounded-2xl border border-stone-200 shadow-sm flex flex-col md:flex-row gap-3 items-center justify-between">
        
        <div className="relative w-full md:w-80">
          <Search className="w-4 h-4 text-stone-400 absolute left-3 top-2.5" />
          <input
            type="text"
            placeholder="ค้นหาชื่อสินค้า, รหัส SKU..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-9 pr-3 py-2 text-xs bg-stone-50 border border-stone-300 rounded-xl"
          />
        </div>

        <div className="flex flex-wrap gap-1.5 w-full md:w-auto">
          {[
            { id: 'all', label: 'ทั้งหมด' },
            { id: 'bicycle', label: '🚲 จักรยาน' },
            { id: 'parts', label: '⚙️ อะไหล่' },
            { id: 'accessories', label: '🎒 อุปกรณ์' },
            { id: 'apparel', label: '👕 เสื้อผ้า' },
            { id: 'service', label: '🔧 งานช่าง & ฟิตติ้ง' },
          ].map(cat => (
            <button
              key={cat.id}
              onClick={() => setSelectedCategory(cat.id)}
              className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition-all ${
                selectedCategory === cat.id
                  ? 'bg-stone-900 text-amber-400'
                  : 'bg-stone-100 hover:bg-stone-200 text-stone-700'
              }`}
            >
              {cat.label}
            </button>
          ))}
        </div>
      </div>

      {/* Products Table */}
      <div className="bg-white rounded-2xl border border-stone-200 shadow-sm overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="bg-stone-100 text-stone-700 font-semibold text-[11px] uppercase border-b border-stone-200">
                <th className="py-3 px-3 w-28">รหัสสินค้า</th>
                <th className="py-3 px-3">ชื่อสินค้าและบริการ</th>
                <th className="py-3 px-3 w-28 text-center">หมวดหมู่</th>
                <th className="py-3 px-3 w-24 text-right">ราคา/หน่วย</th>
                <th className="py-3 px-3 w-20 text-center">หน่วย</th>
                <th className="py-3 px-3 w-24 text-center">คงเหลือ</th>
                <th className="py-3 px-3 w-24 text-center">การจัดการ</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-stone-200">
              {filtered.map(item => (
                <tr key={item.id} className="hover:bg-stone-50/70 transition-colors">
                  <td className="py-3 px-3 font-mono font-bold text-stone-700 text-[11px]">
                    {item.code}
                  </td>
                  <td className="py-3 px-3 space-y-0.5">
                    <p className="font-bold text-stone-900">{item.name}</p>
                    {item.nameEn && <p className="text-[10px] text-stone-500">{item.nameEn}</p>}
                    {item.description && <p className="text-[11px] text-stone-600 line-clamp-1">{item.description}</p>}
                    {item.serialRequired && (
                      <span className="inline-block text-[9px] px-1.5 py-0.2 rounded bg-amber-50 text-amber-800 border border-amber-200 font-medium">
                        บันทึกเลขตัวถัง (Serial Required)
                      </span>
                    )}
                  </td>
                  <td className="py-3 px-3 text-center">
                    <span className="inline-block px-2 py-0.5 rounded-full text-[10px] font-bold uppercase bg-stone-100 text-stone-700">
                      {item.category}
                    </span>
                  </td>
                  <td className="py-3 px-3 text-right font-mono font-bold text-stone-900">
                    {formatCurrency(item.price, true)}
                  </td>
                  <td className="py-3 px-3 text-center text-stone-600">
                    {item.unit}
                  </td>
                  <td className="py-3 px-3 text-center font-mono">
                    {item.category === 'service' ? (
                      <span className="text-[10px] text-stone-400">งานบริการ</span>
                    ) : (
                      <span className={`px-2 py-0.5 rounded text-[11px] font-bold ${
                        (item.stock ?? 0) <= 2 ? 'bg-rose-50 text-rose-700 border border-rose-200' : 'bg-emerald-50 text-emerald-700'
                      }`}>
                        {item.stock} {item.unit}
                      </span>
                    )}
                  </td>
                  <td className="py-3 px-3 text-center">
                    <div className="flex items-center justify-center gap-1">
                      <button
                        onClick={() => openEditModal(item)}
                        className="p-1.5 text-stone-500 hover:text-amber-600 hover:bg-stone-100 rounded-lg transition-colors"
                      >
                        <Edit3 className="w-3.5 h-3.5" />
                      </button>
                      <button
                        onClick={() => onDeleteProduct(item.id)}
                        className="p-1.5 text-stone-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-colors"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Add / Edit Modal */}
      {modalOpen && (
        <div className="fixed inset-0 z-50 bg-stone-950/70 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-lg w-full p-6 shadow-2xl border border-stone-200 space-y-4">
            
            <div className="flex items-center justify-between pb-3 border-b border-stone-200">
              <h3 className="text-base font-bold text-stone-900 font-heading">
                {editingProduct ? 'แก้ไขข้อมูลสินค้า/บริการ' : 'เพิ่มสินค้า/บริการใหม่'}
              </h3>
              <button
                onClick={() => setModalOpen(false)}
                className="p-1 text-stone-400 hover:text-stone-700 rounded-lg"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSave} className="space-y-4">
              <div className="grid grid-cols-2 gap-3 text-xs">
                
                <div>
                  <label className="block font-semibold text-stone-700 mb-1">รหัสสินค้า (SKU/Code)</label>
                  <input
                    type="text"
                    required
                    value={code}
                    onChange={(e) => setCode(e.target.value)}
                    className="w-full bg-stone-50 border border-stone-300 rounded-xl px-3 py-2 font-mono"
                  />
                </div>

                <div>
                  <label className="block font-semibold text-stone-700 mb-1">หมวดหมู่</label>
                  <select
                    value={category}
                    onChange={(e) => setCategory(e.target.value as ItemCategory)}
                    className="w-full bg-stone-50 border border-stone-300 rounded-xl px-3 py-2"
                  >
                    <option value="bicycle">รถจักรยาน (Bicycle)</option>
                    <option value="parts">อะไหล่ & ชุดขับ (Parts)</option>
                    <option value="accessories">อุปกรณ์ & ของแต่ง (Accessories)</option>
                    <option value="apparel">ชุดปั่น & เครื่องแต่งกาย (Apparel)</option>
                    <option value="service">บริการช่าง & ฟิตติ้ง (Service)</option>
                  </select>
                </div>

                <div className="col-span-2">
                  <label className="block font-semibold text-stone-700 mb-1">ชื่อสินค้า (ภาษาไทย)</label>
                  <input
                    type="text"
                    required
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    className="w-full bg-stone-50 border border-stone-300 rounded-xl px-3 py-2 font-medium"
                    placeholder="เช่น จักรยานเสือหมอบ Dalayar Aero Pro"
                  />
                </div>

                <div className="col-span-2">
                  <label className="block font-semibold text-stone-700 mb-1">ชื่อภาษาอังกฤษ (Optional)</label>
                  <input
                    type="text"
                    value={nameEn}
                    onChange={(e) => setNameEn(e.target.value)}
                    className="w-full bg-stone-50 border border-stone-300 rounded-xl px-3 py-2"
                  />
                </div>

                <div>
                  <label className="block font-semibold text-stone-700 mb-1">ราคาจำหน่าย (฿)</label>
                  <input
                    type="number"
                    min="0"
                    step="any"
                    required
                    value={price}
                    onChange={(e) => setPrice(Number(e.target.value))}
                    className="w-full bg-stone-50 border border-stone-300 rounded-xl px-3 py-2 font-mono font-bold"
                  />
                </div>

                <div>
                  <label className="block font-semibold text-stone-700 mb-1">หน่วยนับ</label>
                  <input
                    type="text"
                    required
                    value={unit}
                    onChange={(e) => setUnit(e.target.value)}
                    className="w-full bg-stone-50 border border-stone-300 rounded-xl px-3 py-2"
                    placeholder="คัน, ชิ้น, ชุด, ครั้ง"
                  />
                </div>

                {category !== 'service' && (
                  <div>
                    <label className="block font-semibold text-stone-700 mb-1">จำนวนสต็อก</label>
                    <input
                      type="number"
                      min="0"
                      value={stock}
                      onChange={(e) => setStock(Number(e.target.value))}
                      className="w-full bg-stone-50 border border-stone-300 rounded-xl px-3 py-2 font-mono"
                    />
                  </div>
                )}

                <div className={category === 'service' ? 'col-span-2' : ''}>
                  <label className="block font-semibold text-stone-700 mb-1">ต้องการบันทึกเลขตัวถัง/Serial</label>
                  <div className="pt-2">
                    <label className="flex items-center gap-2 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={serialRequired}
                        onChange={(e) => setSerialRequired(e.target.checked)}
                        className="rounded text-amber-600 focus:ring-amber-500 border-stone-300"
                      />
                      <span>ต้องระบุ Serial No.</span>
                    </label>
                  </div>
                </div>

                <div className="col-span-2">
                  <label className="block font-semibold text-stone-700 mb-1">รายละเอียดสินค้า/สเปค</label>
                  <textarea
                    rows={2}
                    value={description}
                    onChange={(e) => setDescription(e.target.value)}
                    className="w-full bg-stone-50 border border-stone-300 rounded-xl p-2"
                    placeholder="เช่น เฟรมคาร์บอน T800, ชุดขับ 105 Di2..."
                  />
                </div>

              </div>

              <div className="pt-3 border-t border-stone-200 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setModalOpen(false)}
                  className="px-4 py-2 rounded-xl border border-stone-300 text-xs font-semibold text-stone-700 hover:bg-stone-50"
                >
                  ยกเลิก
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-stone-950 text-xs font-bold shadow-xs"
                >
                  บันทึกสินค้า
                </button>
              </div>
            </form>

          </div>
        </div>
      )}

    </div>
  );
};
