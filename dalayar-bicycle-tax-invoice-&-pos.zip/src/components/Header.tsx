import React from 'react';
import { DALAYAR_COMPANY_INFO } from '../data/companyInfo';
import { 
  FileText, 
  ShoppingBag, 
  Package, 
  Users, 
  BarChart3, 
  PlusCircle, 
  Bike,
  Printer,
  ShieldCheck
} from 'lucide-react';

interface HeaderProps {
  activeTab: 'invoices' | 'pos' | 'catalog' | 'customers' | 'analytics';
  setActiveTab: (tab: 'invoices' | 'pos' | 'catalog' | 'customers' | 'analytics') => void;
  onNewInvoice: () => void;
  invoiceCount: number;
}

export const Header: React.FC<HeaderProps> = ({
  activeTab,
  setActiveTab,
  onNewInvoice,
  invoiceCount,
}) => {
  return (
    <header className="bg-stone-900 text-white shadow-lg sticky top-0 z-40 no-print border-b border-stone-800">
      {/* Top micro bar with company details */}
      <div className="bg-stone-950 px-4 py-1.5 text-xs text-stone-400 border-b border-stone-800/80 flex flex-wrap justify-between items-center gap-2">
        <div className="flex items-center gap-4">
          <span className="flex items-center gap-1.5 text-amber-400 font-medium">
            <ShieldCheck className="w-3.5 h-3.5" />
            ผู้เสียภาษีถูกต้องตามกฎหมาย: {DALAYAR_COMPANY_INFO.taxId}
          </span>
          <span className="hidden sm:inline text-stone-500">|</span>
          <span className="hidden sm:inline">สำนักงานใหญ่: อ.มัญจาคีรี จ.ขอนแก่น</span>
        </div>
        <div className="flex items-center gap-4 text-stone-400">
          <span>โทร: {DALAYAR_COMPANY_INFO.phone}</span>
          <span className="hidden sm:inline">|</span>
          <span className="hidden sm:inline">{DALAYAR_COMPANY_INFO.email}</span>
        </div>
      </div>

      {/* Main navigation header */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-3">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          
          {/* Logo & Brand title */}
          <div className="flex items-center gap-3">
            <div className="w-11 h-11 rounded-xl bg-gradient-to-br from-amber-500 to-amber-700 flex items-center justify-center shadow-md shadow-amber-900/40 shrink-0 text-white ring-2 ring-amber-400/20">
              <Bike className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-lg sm:text-xl font-bold tracking-tight font-heading text-white flex items-center gap-2">
                  DALAYAR BICYCLE
                  <span className="text-[10px] uppercase font-bold tracking-wider px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-400 border border-amber-500/30">
                    TAX & POS SYSTEM
                  </span>
                </h1>
              </div>
              <p className="text-xs text-stone-400">
                ดาลาญาร์ ไลฟ์สไตล์จักรยาน • ระบบออกใบกำกับภาษี / ใบเสร็จรับเงิน
              </p>
            </div>
          </div>

          {/* Navigation tabs & Action */}
          <div className="flex flex-wrap items-center gap-2 sm:gap-3">
            <nav className="flex items-center bg-stone-800/90 p-1 rounded-xl border border-stone-700/60 shadow-inner">
              <button
                id="nav-invoices-btn"
                onClick={() => setActiveTab('invoices')}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs sm:text-sm font-medium transition-all ${
                  activeTab === 'invoices'
                    ? 'bg-amber-500 text-stone-950 font-semibold shadow-sm'
                    : 'text-stone-300 hover:text-white hover:bg-stone-700/50'
                }`}
              >
                <FileText className="w-4 h-4" />
                <span>เอกสาร / ใบกำกับภาษี</span>
                {invoiceCount > 0 && (
                  <span className={`text-[10px] px-1.5 py-0.2 rounded-full ${
                    activeTab === 'invoices' ? 'bg-stone-900 text-amber-400' : 'bg-stone-700 text-stone-300'
                  }`}>
                    {invoiceCount}
                  </span>
                )}
              </button>

              <button
                id="nav-pos-btn"
                onClick={() => setActiveTab('pos')}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs sm:text-sm font-medium transition-all ${
                  activeTab === 'pos'
                    ? 'bg-amber-500 text-stone-950 font-semibold shadow-sm'
                    : 'text-stone-300 hover:text-white hover:bg-stone-700/50'
                }`}
              >
                <ShoppingBag className="w-4 h-4" />
                <span>จุดขายหน้าร้าน (POS)</span>
              </button>

              <button
                id="nav-catalog-btn"
                onClick={() => setActiveTab('catalog')}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs sm:text-sm font-medium transition-all ${
                  activeTab === 'catalog'
                    ? 'bg-amber-500 text-stone-950 font-semibold shadow-sm'
                    : 'text-stone-300 hover:text-white hover:bg-stone-700/50'
                }`}
              >
                <Package className="w-4 h-4" />
                <span>สินค้า & งานบริการ</span>
              </button>

              <button
                id="nav-customers-btn"
                onClick={() => setActiveTab('customers')}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs sm:text-sm font-medium transition-all ${
                  activeTab === 'customers'
                    ? 'bg-amber-500 text-stone-950 font-semibold shadow-sm'
                    : 'text-stone-300 hover:text-white hover:bg-stone-700/50'
                }`}
              >
                <Users className="w-4 h-4" />
                <span>ลูกค้า</span>
              </button>

              <button
                id="nav-analytics-btn"
                onClick={() => setActiveTab('analytics')}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs sm:text-sm font-medium transition-all ${
                  activeTab === 'analytics'
                    ? 'bg-amber-500 text-stone-950 font-semibold shadow-sm'
                    : 'text-stone-300 hover:text-white hover:bg-stone-700/50'
                }`}
              >
                <BarChart3 className="w-4 h-4" />
                <span>รายงานภาษีขาย</span>
              </button>
            </nav>

            <button
              id="header-create-invoice-btn"
              onClick={onNewInvoice}
              className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-stone-950 font-semibold text-xs sm:text-sm transition-all shadow-md shadow-amber-950/40 active:scale-95"
            >
              <PlusCircle className="w-4 h-4" />
              <span>สร้างเอกสารใหม่</span>
            </button>
          </div>

        </div>
      </div>
    </header>
  );
};
