import React, { useEffect, useState } from 'react';
import { InvoiceDocument } from '../types';
import { DALAYAR_COMPANY_INFO } from '../data/companyInfo';
import { formatCurrency } from '../utils/thaiBahtText';
import { generatePromptPayPayload, generateQrDataUrl } from '../utils/promptpay';
import { Printer, Bike, X } from 'lucide-react';

interface ThermalReceiptProps {
  invoice: InvoiceDocument;
  onClose?: () => void;
}

export const ThermalReceipt: React.FC<ThermalReceiptProps> = ({ invoice, onClose }) => {
  const [qrUrl, setQrUrl] = useState<string>('');

  useEffect(() => {
    async function loadQr() {
      const amountToPay = invoice.netPayable || invoice.grandTotal;
      const payload = generatePromptPayPayload(DALAYAR_COMPANY_INFO.promptpayId, amountToPay);
      const url = await generateQrDataUrl(payload);
      setQrUrl(url);
    }
    loadQr();
  }, [invoice.grandTotal, invoice.netPayable]);

  const handlePrintSlip = () => {
    window.print();
  };

  return (
    <div className="fixed inset-0 z-50 bg-stone-950/70 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto">
      <div className="bg-white rounded-2xl max-w-sm w-full p-4 sm:p-6 shadow-2xl border border-stone-200 relative my-auto">
        
        {/* Modal Controls */}
        <div className="no-print flex items-center justify-between pb-3 mb-3 border-b border-stone-200">
          <span className="text-xs font-bold text-stone-800 flex items-center gap-1.5">
            <Printer className="w-4 h-4 text-amber-600" />
            ตัวอย่างสลิปใบเสร็จ (80mm POS Slip)
          </span>
          <div className="flex items-center gap-2">
            <button
              onClick={handlePrintSlip}
              className="px-3 py-1 bg-stone-900 hover:bg-stone-800 text-white rounded-lg text-xs font-semibold flex items-center gap-1 shadow-xs"
            >
              <Printer className="w-3.5 h-3.5" />
              พิมพ์สลิป
            </button>
            {onClose && (
              <button
                onClick={onClose}
                className="p-1 text-stone-400 hover:text-stone-700 rounded-lg hover:bg-stone-100"
              >
                <X className="w-4 h-4" />
              </button>
            )}
          </div>
        </div>

        {/* 80mm Thermal Receipt Content */}
        <div 
          id="thermal-slip-print"
          className="font-mono text-stone-900 text-[11px] leading-tight space-y-2 bg-stone-50 p-4 rounded-xl border border-stone-200 shadow-inner"
        >
          {/* Header */}
          <div className="text-center space-y-1 pb-2 border-b border-dashed border-stone-400">
            <div className="w-8 h-8 rounded-full bg-stone-900 text-amber-400 mx-auto flex items-center justify-center font-bold">
              <Bike className="w-4 h-4" />
            </div>
            <p className="font-bold text-xs">{DALAYAR_COMPANY_INFO.nameEn}</p>
            <p className="text-[10px]">{DALAYAR_COMPANY_INFO.nameTh}</p>
            <p className="text-[9px] text-stone-600">{DALAYAR_COMPANY_INFO.address}</p>
            <p className="text-[9px]">เลขประจำตัวผู้เสียภาษี: {DALAYAR_COMPANY_INFO.taxId}</p>
            <p className="text-[9px]">โทร: {DALAYAR_COMPANY_INFO.phone}</p>
          </div>

          {/* Doc Title & Meta */}
          <div className="text-center py-1">
            <p className="font-bold text-xs uppercase tracking-wider">
              {invoice.type === 'TAX_INVOICE_RECEIPT' ? 'ใบกำกับภาษีอย่างย่อ / ใบเสร็จรับเงิน' : 'ใบเสร็จรับเงิน'}
            </p>
            <p className="text-[9px] text-stone-500">(TAX INVOICE / RECEIPT ABB.)</p>
          </div>

          <div className="text-[10px] space-y-0.5 pb-2 border-b border-dashed border-stone-300">
            <div className="flex justify-between">
              <span>เลขที่ (No):</span>
              <span className="font-bold">{invoice.documentNumber}</span>
            </div>
            <div className="flex justify-between">
              <span>วันที่ (Date):</span>
              <span>{invoice.issueDate} {invoice.payment.paidAt ? invoice.payment.paidAt.split(' ')[1] || '' : ''}</span>
            </div>
            <div className="flex justify-between">
              <span>พนักงาน (Staff):</span>
              <span>{invoice.salesPerson || 'DALAYAR'}</span>
            </div>
            <div className="flex justify-between">
              <span>ลูกค้า (Customer):</span>
              <span className="truncate max-w-[140px]">{invoice.customer.name || 'ลูกค้าหน้าร้าน'}</span>
            </div>
            {invoice.customer.taxId && (
              <div className="flex justify-between">
                <span>Tax ID ลูกค้า:</span>
                <span>{invoice.customer.taxId}</span>
              </div>
            )}
          </div>

          {/* Line Items */}
          <div className="py-1 space-y-1.5 border-b border-dashed border-stone-400">
            {invoice.items.map((item, idx) => (
              <div key={idx} className="space-y-0.5">
                <div className="flex justify-between font-bold text-[11px]">
                  <span className="truncate pr-2">{item.name}</span>
                  <span>{formatCurrency(item.totalPrice, false)}</span>
                </div>
                <div className="flex justify-between text-[10px] text-stone-600">
                  <span>{item.quantity} {item.unit} x {formatCurrency(item.unitPrice, false)}</span>
                  {item.discountValue > 0 && (
                    <span className="text-rose-600">
                      ลด {item.discountValue}{item.discountType === 'percent' ? '%' : ''}
                    </span>
                  )}
                </div>
                {item.serialNumber && (
                  <div className="text-[9px] text-stone-500">
                    SN/Frame: {item.serialNumber}
                  </div>
                )}
              </div>
            ))}
          </div>

          {/* Summary Totals */}
          <div className="space-y-1 text-[11px] pt-1 pb-2 border-b border-dashed border-stone-400">
            <div className="flex justify-between">
              <span>รวมเป็นเงิน:</span>
              <span>{formatCurrency(invoice.subtotal, false)}</span>
            </div>
            {(invoice.itemDiscountTotal > 0 || invoice.overallDiscountAmount > 0) && (
              <div className="flex justify-between text-rose-600">
                <span>ส่วนลด:</span>
                <span>-{formatCurrency((invoice.itemDiscountTotal || 0) + (invoice.overallDiscountAmount || 0), false)}</span>
              </div>
            )}
            <div className="flex justify-between text-stone-600 text-[10px]">
              <span>มูลค่าก่อน VAT:</span>
              <span>{formatCurrency(invoice.netBeforeVat, false)}</span>
            </div>
            <div className="flex justify-between text-stone-600 text-[10px]">
              <span>ภาษีมูลค่าเพิ่ม (VAT 7%):</span>
              <span>{formatCurrency(invoice.vatAmount, false)}</span>
            </div>
            <div className="flex justify-between font-bold text-xs pt-1 border-t border-stone-300">
              <span>ยอดสุทธิ (TOTAL):</span>
              <span className="text-stone-950 font-extrabold">
                {formatCurrency(invoice.netPayable || invoice.grandTotal, true)}
              </span>
            </div>
            <p className="text-[9px] text-stone-600 text-right">({invoice.bahtText})</p>
          </div>

          {/* Payment info & Change */}
          <div className="text-[10px] space-y-0.5 pt-1 pb-2 border-b border-dashed border-stone-400">
            <div className="flex justify-between">
              <span>ชำระโดย (Paid by):</span>
              <span className="font-semibold uppercase">{invoice.payment.method}</span>
            </div>
            <div className="flex justify-between">
              <span>รับเงินมา:</span>
              <span>{formatCurrency(invoice.payment.paidAmount || invoice.grandTotal, true)}</span>
            </div>
            {invoice.payment.changeAmount > 0 && (
              <div className="flex justify-between font-bold text-emerald-700">
                <span>เงินทอน (Change):</span>
                <span>{formatCurrency(invoice.payment.changeAmount, true)}</span>
              </div>
            )}
          </div>

          {/* PromptPay QR Code */}
          {qrUrl && (
            <div className="text-center py-2 space-y-1">
              <img src={qrUrl} alt="PromptPay" className="w-24 h-24 mx-auto border border-stone-300 rounded p-1 bg-white" referrerPolicy="no-referrer" />
              <p className="text-[9px] font-bold text-stone-700">สแกนชำระผ่านพร้อมเพย์</p>
              <p className="text-[8px] text-stone-500">{DALAYAR_COMPANY_INFO.promptpayId}</p>
            </div>
          )}

          {/* Footer message */}
          <div className="text-center text-[9px] text-stone-600 pt-2 space-y-0.5">
            <p>*** ขอบคุณที่ใช้บริการ ***</p>
            <p>THANK YOU FOR RIDING WITH DALAYAR</p>
            <p className="text-[8px] text-stone-400">พบปัญหาติดต่อ: {DALAYAR_COMPANY_INFO.phone}</p>
          </div>
        </div>

      </div>
    </div>
  );
};
