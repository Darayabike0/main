import React, { useState, useEffect } from 'react';
import { 
  InvoiceDocument, 
  InvoiceItem, 
  Customer, 
  DocumentType, 
  ProductItem,
  PaymentMethod 
} from '../types';
import { DALAYAR_COMPANY_INFO } from '../data/companyInfo';
import { calculateInvoiceTotals } from '../utils/taxCalculator';
import { formatCurrency } from '../utils/thaiBahtText';
import { 
  Plus, 
  Trash2, 
  Search, 
  Save, 
  Eye, 
  FileText, 
  Calendar, 
  UserPlus, 
  Building2, 
  User, 
  Percent, 
  CreditCard,
  QrCode,
  Banknote,
  Bike,
  Wrench,
  Check
} from 'lucide-react';

interface InvoiceEditorProps {
  initialInvoice?: InvoiceDocument | null;
  catalog: ProductItem[];
  customers: Customer[];
  onSave: (invoice: InvoiceDocument) => void;
  onPreview: (invoice: InvoiceDocument) => void;
  onCancel: () => void;
}

export const InvoiceEditor: React.FC<InvoiceEditorProps> = ({
  initialInvoice,
  catalog,
  customers,
  onSave,
  onPreview,
  onCancel,
}) => {
  // Generate default doc number if new
  const generateNewDocNumber = (type: DocumentType) => {
    const today = new Date();
    const yyyymm = `${today.getFullYear()}${String(today.getMonth() + 1).padStart(2, '0')}`;
    const prefix = type === 'TAX_INVOICE_RECEIPT' ? 'TAX' 
      : type === 'QUOTATION' ? 'QT' 
      : type === 'INVOICE' ? 'INV' 
      : type === 'DELIVERY_NOTE' ? 'DO' 
      : 'RCP';
    const randomSeq = String(Math.floor(Math.random() * 900) + 100);
    return `${prefix}-${yyyymm}-${randomSeq}`;
  };

  const [docType, setDocType] = useState<DocumentType>(initialInvoice?.type || 'TAX_INVOICE_RECEIPT');
  const [docNumber, setDocNumber] = useState<string>(initialInvoice?.documentNumber || generateNewDocNumber('TAX_INVOICE_RECEIPT'));
  const [issueDate, setIssueDate] = useState<string>(initialInvoice?.issueDate || new Date().toISOString().split('T')[0]);
  const [dueDate, setDueDate] = useState<string>(initialInvoice?.dueDate || new Date().toISOString().split('T')[0]);
  const [referenceNumber, setReferenceNumber] = useState<string>(initialInvoice?.referenceNumber || '');
  const [salesPerson, setSalesPerson] = useState<string>(initialInvoice?.salesPerson || 'ดาราญาร์ (DALAYAR Staff)');
  
  // Customer
  const [selectedCustomerId, setSelectedCustomerId] = useState<string>(initialInvoice?.customer?.id || '');
  const [customer, setCustomer] = useState<Customer>(initialInvoice?.customer || {
    id: `cust-${Date.now()}`,
    type: 'individual',
    name: 'ลูกค้าทั่วไป (Walk-in)',
    address: '5/1 หมู่ 13 ต.มัญจาคีรี อ.มัญจาคีรี จ.ขอนแก่น 40160',
    phone: '084-014-8961',
  });

  // Items
  const [items, setItems] = useState<InvoiceItem[]>(initialInvoice?.items || [
    {
      id: `item-${Date.now()}`,
      code: 'BK-GRV-01',
      name: 'จักรยานกราเวล Dalayar All-Road Gravel Disc (Carbon Frame)',
      description: 'เฟรมคาร์บอน T800, ชุดขับ Shimano GRX 11-Speed',
      serialNumber: 'DLR-GRV-2026-0912',
      category: 'bicycle',
      quantity: 1,
      unit: 'คัน',
      unitPrice: 45900,
      discountType: 'amount',
      discountValue: 0,
      totalPrice: 45900,
    }
  ]);

  // Tax settings
  const [vatType, setVatType] = useState<'included' | 'excluded' | 'none'>(initialInvoice?.vatType || 'included');
  const [vatRate, setVatRate] = useState<number>(initialInvoice?.vatRate ?? 7);
  const [withholdingTaxRate, setWithholdingTaxRate] = useState<number>(initialInvoice?.withholdingTaxRate ?? 0);
  const [overallDiscountType, setOverallDiscountType] = useState<'percent' | 'amount'>(initialInvoice?.overallDiscountType || 'amount');
  const [overallDiscountValue, setOverallDiscountValue] = useState<number>(initialInvoice?.overallDiscountValue ?? 0);

  // Payment
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>(initialInvoice?.payment?.method || 'promptpay');
  const [paidAmount, setPaidAmount] = useState<number>(initialInvoice?.payment?.paidAmount || 0);
  const [docStatus, setDocStatus] = useState<'draft' | 'issued' | 'paid' | 'cancelled'>(initialInvoice?.status || 'paid');
  
  // Notes & terms
  const [notes, setNotes] = useState<string>(initialInvoice?.notes || 'รับประกันเฟรมจักรยานคาร์บอน 5 ปี, บริการจูนเกียร์ฟรีตลอดอายุการใช้งาน');
  const [terms, setTerms] = useState<string>(initialInvoice?.terms || 'สินค้าซื้อแล้วสามารถเปลี่ยนได้ภายใน 7 วันในสภาพสมบูรณ์พร้อมใบเสร็จ');

  // Search in catalog modal
  const [searchCatalogOpen, setSearchCatalogOpen] = useState<boolean>(false);
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [catalogFilterCategory, setCatalogFilterCategory] = useState<string>('all');

  // When docType changes, update doc number prefix if new
  const handleDocTypeChange = (newType: DocumentType) => {
    setDocType(newType);
    if (!initialInvoice) {
      setDocNumber(generateNewDocNumber(newType));
    }
  };

  // When customer picker selected
  const handleSelectCustomer = (custId: string) => {
    setSelectedCustomerId(custId);
    const found = customers.find(c => c.id === custId);
    if (found) {
      setCustomer({ ...found });
    }
  };

  // Recalculate item totalPrice
  const updateItem = (index: number, field: keyof InvoiceItem, value: any) => {
    const newItems = [...items];
    const item = { ...newItems[index], [field]: value };
    
    // Calculate total price for item
    const raw = (Number(item.quantity) || 0) * (Number(item.unitPrice) || 0);
    let discount = 0;
    if (item.discountType === 'percent') {
      discount = raw * ((Number(item.discountValue) || 0) / 100);
    } else {
      discount = Number(item.discountValue) || 0;
    }
    discount = Math.min(discount, raw);
    item.totalPrice = Math.round((raw - discount) * 100) / 100;
    
    newItems[index] = item;
    setItems(newItems);
  };

  const addItemFromCatalog = (product: ProductItem) => {
    const newItem: InvoiceItem = {
      id: `item-${Date.now()}-${Math.random()}`,
      code: product.code,
      name: product.name,
      description: product.description,
      serialNumber: product.serialRequired ? `DLR-${product.code.split('-')[1] || 'BIKE'}-${new Date().getFullYear()}-${Math.floor(Math.random() * 8999 + 1000)}` : undefined,
      category: product.category,
      quantity: 1,
      unit: product.unit,
      unitPrice: product.price,
      discountType: 'amount',
      discountValue: 0,
      totalPrice: product.price,
    };
    setItems([...items, newItem]);
    setSearchCatalogOpen(false);
  };

  const addNewBlankItem = () => {
    const newItem: InvoiceItem = {
      id: `item-${Date.now()}`,
      code: 'CUSTOM',
      name: 'สินค้า / บริการใหม่',
      category: 'custom',
      quantity: 1,
      unit: 'รายการ',
      unitPrice: 1000,
      discountType: 'amount',
      discountValue: 0,
      totalPrice: 1000,
    };
    setItems([...items, newItem]);
  };

  const removeItem = (index: number) => {
    if (items.length <= 1) return;
    const newItems = items.filter((_, idx) => idx !== index);
    setItems(newItems);
  };

  // Compute live calculations
  const totals = calculateInvoiceTotals(
    items,
    vatType,
    vatRate,
    withholdingTaxRate,
    overallDiscountType,
    overallDiscountValue
  );

  // Auto-set paid amount to grand total if docStatus is paid and paidAmount is 0
  useEffect(() => {
    if (docStatus === 'paid' && (paidAmount === 0 || paidAmount === totals.grandTotal)) {
      setPaidAmount(totals.netPayable || totals.grandTotal);
    }
  }, [totals.netPayable, totals.grandTotal, docStatus]);

  const compileDocument = (): InvoiceDocument => {
    const finalAmount = totals.netPayable || totals.grandTotal;
    const change = Math.max(0, (paidAmount || 0) - finalAmount);

    return {
      id: initialInvoice?.id || `inv-${Date.now()}`,
      documentNumber: docNumber,
      type: docType,
      issueDate,
      dueDate,
      referenceNumber,
      salesPerson,
      customer,
      items,
      vatType,
      vatRate,
      withholdingTaxRate,
      overallDiscountType,
      overallDiscountValue,
      subtotal: totals.subtotal,
      itemDiscountTotal: totals.itemDiscountTotal,
      overallDiscountAmount: totals.overallDiscountAmount,
      netBeforeVat: totals.netBeforeVat,
      vatAmount: totals.vatAmount,
      withholdingTaxAmount: totals.withholdingTaxAmount,
      grandTotal: totals.grandTotal,
      netPayable: totals.netPayable,
      bahtText: totals.bahtText,
      payment: {
        method: paymentMethod,
        paidAmount: docStatus === 'paid' ? (paidAmount || finalAmount) : 0,
        changeAmount: docStatus === 'paid' ? change : 0,
        paidAt: `${issueDate} 10:30`,
        promptPayId: DALAYAR_COMPANY_INFO.promptpayId,
      },
      status: docStatus,
      notes,
      terms,
      authorizedSignatureName: 'ดาราญาร์ ดิษฐ์ (ผู้มีอำนาจลงนาม)',
      authorizedSignatureTitle: 'Managing Director / กรรมการผู้จัดการ',
      isSigned: true,
      signatureDate: issueDate,
      copyType: 'original',
    };
  };

  const handleSaveDocument = (e: React.FormEvent) => {
    e.preventDefault();
    const doc = compileDocument();
    onSave(doc);
  };

  const handlePreviewDocument = () => {
    const doc = compileDocument();
    onPreview(doc);
  };

  const filteredCatalog = catalog.filter(p => {
    const matchesCategory = catalogFilterCategory === 'all' || p.category === catalogFilterCategory;
    const matchesSearch = p.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
                          p.code.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  return (
    <div className="w-full max-w-5xl mx-auto space-y-6">
      <form onSubmit={handleSaveDocument} className="space-y-6">
        
        {/* Top Header Card */}
        <div className="bg-white p-5 sm:p-6 rounded-2xl border border-stone-200 shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2">
              <div className="w-9 h-9 rounded-xl bg-amber-500 text-stone-950 flex items-center justify-center font-bold">
                <FileText className="w-5 h-5" />
              </div>
              <h2 className="text-lg font-bold text-stone-900 font-heading">
                {initialInvoice ? 'แก้ไขเอกสารใบกำกับภาษี / ใบเสร็จ' : 'สร้างใบกำกับภาษี / ใบเสร็จรับเงินใหม่'}
              </h2>
            </div>
            <p className="text-xs text-stone-500 mt-1 pl-11">
              DALAYAR BICYCLE LIFESTYLE COMPANY • สาขามัญจาคีรี จ.ขอนแก่น
            </p>
          </div>

          <div className="flex items-center gap-2.5">
            <button
              type="button"
              onClick={onCancel}
              className="px-4 py-2 rounded-xl border border-stone-300 text-stone-700 hover:bg-stone-50 text-xs font-semibold transition-all"
            >
              ยกเลิก
            </button>
            <button
              type="button"
              onClick={handlePreviewDocument}
              className="px-4 py-2 rounded-xl bg-stone-100 hover:bg-stone-200 text-stone-800 text-xs font-semibold flex items-center gap-1.5 transition-all"
            >
              <Eye className="w-4 h-4 text-stone-600" />
              ดูตัวอย่างเอกสาร A4
            </button>
            <button
              type="submit"
              id="save-invoice-btn"
              className="px-5 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-stone-950 font-bold text-xs flex items-center gap-1.5 transition-all shadow-sm active:scale-95"
            >
              <Save className="w-4 h-4" />
              บันทึกเอกสาร
            </button>
          </div>
        </div>

        {/* 1. Document Configuration Bar */}
        <div className="bg-white p-5 rounded-2xl border border-stone-200 shadow-sm space-y-4">
          <h3 className="text-xs font-bold text-stone-600 uppercase tracking-wider flex items-center gap-1.5">
            <FileText className="w-4 h-4 text-amber-600" />
            ประเภทและข้อมูลเอกสาร (DOCUMENT INFO)
          </h3>

          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4">
            
            <div>
              <label className="block text-xs font-semibold text-stone-700 mb-1">
                ประเภทเอกสาร <span className="text-rose-500">*</span>
              </label>
              <select
                value={docType}
                onChange={(e) => handleDocTypeChange(e.target.value as DocumentType)}
                className="w-full text-xs font-medium bg-stone-50 border border-stone-300 rounded-xl px-3 py-2 focus:ring-2 focus:ring-amber-500 focus:border-amber-500"
              >
                <option value="TAX_INVOICE_RECEIPT">ใบกำกับภาษี / ใบเสร็จรับเงิน (TAX INVOICE/RECEIPT)</option>
                <option value="TAX_INVOICE">ใบกำกับภาษี (TAX INVOICE)</option>
                <option value="RECEIPT">ใบเสร็จรับเงิน (RECEIPT)</option>
                <option value="QUOTATION">ใบเสนอราคา (QUOTATION)</option>
                <option value="INVOICE">ใบแจ้งหนี้ / ใบวางบิล (INVOICE)</option>
                <option value="DELIVERY_NOTE">ใบส่งของ / ใบกำกับภาษี (DELIVERY ORDER)</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-stone-700 mb-1">
                เลขที่เอกสาร <span className="text-rose-500">*</span>
              </label>
              <input
                type="text"
                value={docNumber}
                onChange={(e) => setDocNumber(e.target.value)}
                required
                className="w-full text-xs font-mono font-bold bg-stone-50 border border-stone-300 rounded-xl px-3 py-2 focus:ring-2 focus:ring-amber-500"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-stone-700 mb-1">
                วันที่ออกเอกสาร (Issue Date)
              </label>
              <input
                type="date"
                value={issueDate}
                onChange={(e) => setIssueDate(e.target.value)}
                className="w-full text-xs bg-stone-50 border border-stone-300 rounded-xl px-3 py-2 focus:ring-2 focus:ring-amber-500"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-stone-700 mb-1">
                สถานะเอกสาร
              </label>
              <select
                value={docStatus}
                onChange={(e) => setDocStatus(e.target.value as any)}
                className={`w-full text-xs font-bold rounded-xl px-3 py-2 border ${
                  docStatus === 'paid' ? 'bg-emerald-50 text-emerald-800 border-emerald-300' :
                  docStatus === 'issued' ? 'bg-blue-50 text-blue-800 border-blue-300' :
                  'bg-stone-100 text-stone-700 border-stone-300'
                }`}
              >
                <option value="paid">ชำระเงินแล้ว (PAID)</option>
                <option value="issued">ออกเอกสารแล้ว / รอชำระ (PENDING)</option>
                <option value="draft">ฉบับร่าง (DRAFT)</option>
                <option value="cancelled">ยกเลิก (CANCELLED)</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-stone-700 mb-1">
                เลขอ้างอิง / ใบสั่งซื้อ (PO/Ref)
              </label>
              <input
                type="text"
                placeholder="เช่น PO-2026-88"
                value={referenceNumber}
                onChange={(e) => setReferenceNumber(e.target.value)}
                className="w-full text-xs bg-stone-50 border border-stone-300 rounded-xl px-3 py-2"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-stone-700 mb-1">
                พนักงานขาย / ช่างผู้รับผิดชอบ
              </label>
              <input
                type="text"
                value={salesPerson}
                onChange={(e) => setSalesPerson(e.target.value)}
                className="w-full text-xs bg-stone-50 border border-stone-300 rounded-xl px-3 py-2"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-stone-700 mb-1">
                การคิดภาษีมูลค่าเพิ่ม (VAT)
              </label>
              <select
                value={vatType}
                onChange={(e) => setVatType(e.target.value as any)}
                className="w-full text-xs bg-stone-50 border border-stone-300 rounded-xl px-3 py-2 font-medium"
              >
                <option value="included">ราคารวม VAT 7% แล้ว (Included)</option>
                <option value="excluded">ราคาแยก VAT 7% (Excluded)</option>
                <option value="none">ไม่มี VAT / ยกเว้นภาษี (Non-VAT)</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-semibold text-stone-700 mb-1">
                ภาษีหัก ณ ที่จ่าย (Withholding Tax)
              </label>
              <select
                value={withholdingTaxRate}
                onChange={(e) => setWithholdingTaxRate(Number(e.target.value))}
                className="w-full text-xs bg-stone-50 border border-stone-300 rounded-xl px-3 py-2 font-medium"
              >
                <option value={0}>ไม่หัก (0%)</option>
                <option value={1}>หัก 1% (ค่าขนส่ง)</option>
                <option value={3}>หัก 3% (ค่าบริการ / ค่าแรงช่าง)</option>
                <option value={5}>หัก 5% (ค่าเช่า)</option>
              </select>
            </div>

          </div>
        </div>

        {/* 2. Customer Information Card */}
        <div className="bg-white p-5 rounded-2xl border border-stone-200 shadow-sm space-y-4">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <h3 className="text-xs font-bold text-stone-600 uppercase tracking-wider flex items-center gap-1.5">
              <User className="w-4 h-4 text-amber-600" />
              ข้อมูลลูกค้า / ผู้ซื้อ (CUSTOMER DETAILS)
            </h3>

            {/* Quick Customer select dropdown */}
            <div className="flex items-center gap-2">
              <span className="text-xs text-stone-500 font-medium">เลือกลูกค้าจากฐานข้อมูล:</span>
              <select
                value={selectedCustomerId}
                onChange={(e) => handleSelectCustomer(e.target.value)}
                className="text-xs bg-stone-50 border border-stone-300 rounded-lg px-2.5 py-1.5 max-w-xs font-medium"
              >
                <option value="">-- กรอกข้อมูลเอง / ลูกค้าใหม่ --</option>
                {customers.map(c => (
                  <option key={c.id} value={c.id}>
                    {c.type === 'company' ? '🏢 [นิติบุคคล] ' : '👤 [บุคคล] '}
                    {c.name}
                  </option>
                ))}
              </select>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4">
            
            <div>
              <label className="block text-xs font-semibold text-stone-700 mb-1">
                ประเภทลูกค้า
              </label>
              <div className="flex rounded-xl bg-stone-100 p-1 border border-stone-200">
                <button
                  type="button"
                  onClick={() => setCustomer({ ...customer, type: 'individual' })}
                  className={`flex-1 py-1 text-xs font-medium rounded-lg transition-all ${
                    customer.type === 'individual' ? 'bg-white text-stone-900 font-bold shadow-xs' : 'text-stone-600'
                  }`}
                >
                  บุคคลธรรมดา
                </button>
                <button
                  type="button"
                  onClick={() => setCustomer({ ...customer, type: 'company' })}
                  className={`flex-1 py-1 text-xs font-medium rounded-lg transition-all ${
                    customer.type === 'company' ? 'bg-white text-stone-900 font-bold shadow-xs' : 'text-stone-600'
                  }`}
                >
                  นิติบุคคล / บริษัท
                </button>
              </div>
            </div>

            <div className="sm:col-span-2">
              <label className="block text-xs font-semibold text-stone-700 mb-1">
                ชื่อ-นามสกุล / ชื่อบริษัท <span className="text-rose-500">*</span>
              </label>
              <input
                type="text"
                value={customer.name}
                onChange={(e) => setCustomer({ ...customer, name: e.target.value })}
                required
                placeholder="เช่น บริษัท ขอนแก่น ไบค์ จำกัด หรือ คุณสมชาย ใจดี"
                className="w-full text-xs bg-stone-50 border border-stone-300 rounded-xl px-3 py-2 font-medium"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-stone-700 mb-1">
                เบอร์โทรศัพท์
              </label>
              <input
                type="text"
                value={customer.phone || ''}
                onChange={(e) => setCustomer({ ...customer, phone: e.target.value })}
                placeholder="08X-XXX-XXXX"
                className="w-full text-xs bg-stone-50 border border-stone-300 rounded-xl px-3 py-2 font-mono"
              />
            </div>

            <div className="sm:col-span-2">
              <label className="block text-xs font-semibold text-stone-700 mb-1">
                {customer.type === 'company' ? 'เลขประจำตัวผู้เสียภาษีอากร 13 หลัก' : 'เลขบัตรประชาชน / เลขผู้เสียภาษี (ถ้ามี)'}
              </label>
              <input
                type="text"
                value={customer.taxId || customer.idCard || ''}
                onChange={(e) => setCustomer({ ...customer, taxId: e.target.value, idCard: e.target.value })}
                maxLength={13}
                placeholder="เช่น 0405562001892"
                className="w-full text-xs font-mono font-bold bg-stone-50 border border-stone-300 rounded-xl px-3 py-2"
              />
            </div>

            {customer.type === 'company' && (
              <div>
                <label className="block text-xs font-semibold text-stone-700 mb-1">
                  สถานประกอบการ
                </label>
                <div className="flex gap-2">
                  <select
                    value={customer.branchType || 'head'}
                    onChange={(e) => setCustomer({ ...customer, branchType: e.target.value as any })}
                    className="w-1/2 text-xs bg-stone-50 border border-stone-300 rounded-xl px-2 py-2"
                  >
                    <option value="head">สำนักงานใหญ่</option>
                    <option value="branch">สาขา</option>
                  </select>
                  {customer.branchType === 'branch' && (
                    <input
                      type="text"
                      placeholder="สาขาที่ 1 หรือ 00001"
                      value={customer.branchNumber || ''}
                      onChange={(e) => setCustomer({ ...customer, branchNumber: e.target.value })}
                      className="w-1/2 text-xs bg-stone-50 border border-stone-300 rounded-xl px-2 py-2 font-mono"
                    />
                  )}
                </div>
              </div>
            )}

            <div className={customer.type === 'company' ? 'sm:col-span-4' : 'sm:col-span-3'}>
              <label className="block text-xs font-semibold text-stone-700 mb-1">
                ที่อยู่สำหรับออกใบกำกับภาษี
              </label>
              <input
                type="text"
                value={customer.address || ''}
                onChange={(e) => setCustomer({ ...customer, address: e.target.value })}
                placeholder="เลขที่ ถนน ตำบล อำเภอ จังหวัด รหัสไปรษณีย์"
                className="w-full text-xs bg-stone-50 border border-stone-300 rounded-xl px-3 py-2"
              />
            </div>

          </div>
        </div>

        {/* 3. Items & Services Table */}
        <div className="bg-white p-5 rounded-2xl border border-stone-200 shadow-sm space-y-4">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div>
              <h3 className="text-xs font-bold text-stone-600 uppercase tracking-wider flex items-center gap-1.5">
                <Bike className="w-4 h-4 text-amber-600" />
                รายการสินค้า / รถจักรยาน / อะไหล่ / งานบริการช่าง
              </h3>
              <p className="text-xs text-stone-400">
                เลือกสินค้าจากสต็อกจักรยาน ดาลาญาร์ หรือเพิ่มรายการกำหนดเอง
              </p>
            </div>

            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => setSearchCatalogOpen(true)}
                className="px-3.5 py-1.5 bg-amber-500 hover:bg-amber-400 text-stone-950 font-bold rounded-xl text-xs flex items-center gap-1.5 shadow-xs transition-all"
              >
                <Search className="w-3.5 h-3.5" />
                ค้นหาสินค้าจากสต็อก
              </button>
              <button
                type="button"
                onClick={addNewBlankItem}
                className="px-3 py-1.5 border border-stone-300 hover:bg-stone-50 text-stone-700 rounded-xl text-xs font-medium flex items-center gap-1 transition-all"
              >
                <Plus className="w-3.5 h-3.5" />
                เพิ่มแถวเปล่า
              </button>
            </div>
          </div>

          {/* Table */}
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs border-collapse min-w-[700px]">
              <thead>
                <tr className="bg-stone-100 text-stone-700 font-semibold text-[11px] uppercase border-y border-stone-200">
                  <th className="py-2.5 px-2 text-center w-10">#</th>
                  <th className="py-2.5 px-3">รายการ / คำอธิบาย / Serial เฟรม</th>
                  <th className="py-2.5 px-2 text-center w-20">จำนวน</th>
                  <th className="py-2.5 px-2 text-center w-20">หน่วย</th>
                  <th className="py-2.5 px-3 text-right w-28">ราคา/หน่วย (฿)</th>
                  <th className="py-2.5 px-2 text-right w-28">ส่วนลด</th>
                  <th className="py-2.5 px-3 text-right w-28">รวม (฿)</th>
                  <th className="py-2.5 px-2 text-center w-10"></th>
                </tr>
              </thead>
              <tbody className="divide-y divide-stone-200">
                {items.map((item, idx) => (
                  <tr key={item.id || idx} className="hover:bg-stone-50/70">
                    <td className="py-3 px-2 text-center text-stone-500 font-mono">
                      {idx + 1}
                    </td>

                    {/* Name & Details */}
                    <td className="py-3 px-3 space-y-1">
                      <input
                        type="text"
                        value={item.name}
                        onChange={(e) => updateItem(idx, 'name', e.target.value)}
                        placeholder="ชื่อสินค้า / งานบริการ"
                        className="w-full text-xs font-semibold bg-stone-50 border border-stone-300 rounded-lg px-2 py-1"
                      />
                      <div className="flex gap-2">
                        <input
                          type="text"
                          value={item.description || ''}
                          onChange={(e) => updateItem(idx, 'description', e.target.value)}
                          placeholder="รายละเอียดเพิ่มเติม เช่น ไซส์, สเปคชุดเกียร์"
                          className="w-2/3 text-[11px] bg-stone-50/70 border border-stone-200 rounded px-2 py-0.5 text-stone-600"
                        />
                        <input
                          type="text"
                          value={item.serialNumber || ''}
                          onChange={(e) => updateItem(idx, 'serialNumber', e.target.value)}
                          placeholder="เลขตัวถัง/Frame No./Serial"
                          className="w-1/3 text-[11px] font-mono bg-amber-50/50 border border-amber-200 rounded px-2 py-0.5 text-amber-900"
                        />
                      </div>
                    </td>

                    {/* Qty */}
                    <td className="py-3 px-2">
                      <input
                        type="number"
                        min="1"
                        value={item.quantity}
                        onChange={(e) => updateItem(idx, 'quantity', Number(e.target.value))}
                        className="w-full text-xs text-center font-mono font-medium bg-stone-50 border border-stone-300 rounded-lg px-1 py-1"
                      />
                    </td>

                    {/* Unit */}
                    <td className="py-3 px-2">
                      <input
                        type="text"
                        value={item.unit}
                        onChange={(e) => updateItem(idx, 'unit', e.target.value)}
                        className="w-full text-xs text-center bg-stone-50 border border-stone-300 rounded-lg px-1 py-1"
                      />
                    </td>

                    {/* Unit Price */}
                    <td className="py-3 px-3">
                      <input
                        type="number"
                        min="0"
                        step="any"
                        value={item.unitPrice}
                        onChange={(e) => updateItem(idx, 'unitPrice', Number(e.target.value))}
                        className="w-full text-xs text-right font-mono font-medium bg-stone-50 border border-stone-300 rounded-lg px-2 py-1"
                      />
                    </td>

                    {/* Discount */}
                    <td className="py-3 px-2">
                      <div className="flex items-center gap-1">
                        <input
                          type="number"
                          min="0"
                          value={item.discountValue}
                          onChange={(e) => updateItem(idx, 'discountValue', Number(e.target.value))}
                          className="w-16 text-xs text-right font-mono bg-stone-50 border border-stone-300 rounded-lg px-1 py-1"
                        />
                        <button
                          type="button"
                          onClick={() => updateItem(idx, 'discountType', item.discountType === 'percent' ? 'amount' : 'percent')}
                          className="text-[10px] px-1 py-1 bg-stone-200 hover:bg-stone-300 rounded font-semibold text-stone-700"
                        >
                          {item.discountType === 'percent' ? '%' : '฿'}
                        </button>
                      </div>
                    </td>

                    {/* Total Price */}
                    <td className="py-3 px-3 text-right font-mono font-bold text-stone-900">
                      {formatCurrency(item.totalPrice, false)}
                    </td>

                    {/* Delete */}
                    <td className="py-3 px-2 text-center">
                      <button
                        type="button"
                        onClick={() => removeItem(idx)}
                        disabled={items.length <= 1}
                        className="p-1 text-stone-400 hover:text-rose-600 disabled:opacity-30 rounded hover:bg-rose-50"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* 4. Payment & Totals Summary Grid */}
        <div className="grid grid-cols-1 md:grid-cols-12 gap-6">
          
          {/* Payment & Notes (7 cols) */}
          <div className="md:col-span-7 space-y-4">
            
            {/* Payment Method Selector */}
            <div className="bg-white p-5 rounded-2xl border border-stone-200 shadow-sm space-y-3">
              <h3 className="text-xs font-bold text-stone-600 uppercase tracking-wider flex items-center gap-1.5">
                <CreditCard className="w-4 h-4 text-amber-600" />
                วิธีการรับชำระเงิน (PAYMENT METHOD)
              </h3>

              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                {[
                  { id: 'promptpay', label: 'พร้อมเพย์ QR', icon: QrCode },
                  { id: 'transfer', label: 'โอนเงินธนาคาร', icon: Banknote },
                  { id: 'cash', label: 'เงินสด (Cash)', icon: Banknote },
                  { id: 'credit_card', label: 'บัตรเครดิต', icon: CreditCard },
                  { id: 'installment', label: 'ผ่อนชำระ', icon: Percent },
                ].map((pm) => {
                  const Icon = pm.icon;
                  return (
                    <button
                      key={pm.id}
                      type="button"
                      onClick={() => setPaymentMethod(pm.id as PaymentMethod)}
                      className={`flex items-center gap-2 p-2.5 rounded-xl border text-xs font-semibold transition-all ${
                        paymentMethod === pm.id
                          ? 'bg-amber-50 border-amber-400 text-amber-950 ring-2 ring-amber-400/20'
                          : 'bg-stone-50 border-stone-200 text-stone-700 hover:bg-stone-100'
                      }`}
                    >
                      <Icon className="w-4 h-4 text-amber-600 shrink-0" />
                      <span>{pm.label}</span>
                    </button>
                  );
                })}
              </div>

              {/* Amount paid input */}
              <div className="pt-2 flex items-center gap-3">
                <label className="text-xs font-semibold text-stone-700">
                  จำนวนเงินที่รับชำระ:
                </label>
                <div className="relative flex-1">
                  <input
                    type="number"
                    step="any"
                    value={paidAmount}
                    onChange={(e) => setPaidAmount(Number(e.target.value))}
                    className="w-full text-xs font-mono font-bold bg-stone-50 border border-stone-300 rounded-xl px-3 py-2"
                  />
                </div>
              </div>
            </div>

            {/* Notes & Terms */}
            <div className="bg-white p-5 rounded-2xl border border-stone-200 shadow-sm space-y-3">
              <div>
                <label className="block text-xs font-semibold text-stone-700 mb-1">
                  หมายเหตุท้ายบิล (Notes)
                </label>
                <textarea
                  rows={2}
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  className="w-full text-xs bg-stone-50 border border-stone-300 rounded-xl p-2.5"
                  placeholder="เช่น เงื่อนไขการรับประกันเฟรมและงานช่าง..."
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-stone-700 mb-1">
                  เงื่อนไขการคืน/เปลี่ยนสินค้า (Terms)
                </label>
                <input
                  type="text"
                  value={terms}
                  onChange={(e) => setTerms(e.target.value)}
                  className="w-full text-xs bg-stone-50 border border-stone-300 rounded-xl px-3 py-2"
                />
              </div>
            </div>

          </div>

          {/* Totals Summary (5 cols) */}
          <div className="md:col-span-5 bg-stone-900 text-white p-6 rounded-2xl shadow-xl space-y-4 border border-stone-800 self-start">
            <h3 className="text-xs font-bold text-amber-400 uppercase tracking-wider pb-2 border-b border-stone-800">
              สรุปยอดคำนวณภาษีและจำนวนเงิน
            </h3>

            <div className="space-y-2 text-xs">
              <div className="flex justify-between text-stone-300">
                <span>ยอดรวมสินค้า (Subtotal):</span>
                <span className="font-mono font-semibold">{formatCurrency(totals.subtotal, false)}</span>
              </div>

              {totals.itemDiscountTotal > 0 && (
                <div className="flex justify-between text-rose-400">
                  <span>ส่วนลดรายการ (Item Disc.):</span>
                  <span className="font-mono">-{formatCurrency(totals.itemDiscountTotal, false)}</span>
                </div>
              )}

              {/* Overall Discount input */}
              <div className="flex justify-between items-center py-1 border-t border-stone-800">
                <span className="text-stone-300">ส่วนลดพิเศษท้ายบิล:</span>
                <div className="flex items-center gap-1">
                  <input
                    type="number"
                    min="0"
                    value={overallDiscountValue}
                    onChange={(e) => setOverallDiscountValue(Number(e.target.value))}
                    className="w-20 text-xs text-right font-mono bg-stone-800 border border-stone-700 rounded px-1.5 py-0.5 text-white"
                  />
                  <button
                    type="button"
                    onClick={() => setOverallDiscountType(overallDiscountType === 'percent' ? 'amount' : 'percent')}
                    className="text-[10px] px-1 py-0.5 bg-stone-700 hover:bg-stone-600 rounded font-semibold text-amber-300"
                  >
                    {overallDiscountType === 'percent' ? '%' : '฿'}
                  </button>
                </div>
              </div>

              <div className="flex justify-between text-stone-300 pt-2 border-t border-stone-800">
                <span>มูลค่าฐานภาษี (Net Before VAT):</span>
                <span className="font-mono font-semibold">{formatCurrency(totals.netBeforeVat, false)}</span>
              </div>

              <div className="flex justify-between text-stone-300">
                <span>ภาษีมูลค่าเพิ่ม VAT {vatRate}%:</span>
                <span className="font-mono font-semibold text-amber-400">{formatCurrency(totals.vatAmount, false)}</span>
              </div>

              {totals.withholdingTaxAmount > 0 && (
                <div className="flex justify-between text-amber-300">
                  <span>หัก ณ ที่จ่าย ({withholdingTaxRate}%):</span>
                  <span className="font-mono">-{formatCurrency(totals.withholdingTaxAmount, false)}</span>
                </div>
              )}

              {/* Grand Total */}
              <div className="pt-3 border-t-2 border-amber-500/50">
                <div className="flex justify-between items-baseline">
                  <span className="text-sm font-bold text-white">ยอดสุทธิที่ต้องชำระ:</span>
                  <span className="font-mono text-2xl font-black text-amber-400">
                    {formatCurrency(totals.netPayable || totals.grandTotal, true)}
                  </span>
                </div>
                <p className="text-[11px] text-stone-400 text-right mt-1">
                  ({totals.bahtText})
                </p>
              </div>

            </div>

            {/* Bottom Actions */}
            <div className="pt-4 border-t border-stone-800 flex flex-col gap-2">
              <button
                type="submit"
                className="w-full py-3 bg-amber-500 hover:bg-amber-400 text-stone-950 font-bold rounded-xl text-sm transition-all shadow-md shadow-amber-950/50 flex items-center justify-center gap-2 active:scale-98"
              >
                <Save className="w-4 h-4" />
                บันทึกและออกใบกำกับภาษี
              </button>
            </div>

          </div>

        </div>

      </form>

      {/* Catalog Search Modal */}
      {searchCatalogOpen && (
        <div className="fixed inset-0 z-50 bg-stone-950/70 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl max-w-2xl w-full p-6 shadow-2xl border border-stone-200 space-y-4 max-h-[85vh] flex flex-col">
            
            <div className="flex items-center justify-between pb-3 border-b border-stone-200">
              <div className="flex items-center gap-2">
                <Bike className="w-5 h-5 text-amber-600" />
                <h3 className="text-base font-bold text-stone-900">
                  เลือกสินค้า / งานบริการจักรยาน DALAYAR
                </h3>
              </div>
              <button
                onClick={() => setSearchCatalogOpen(false)}
                className="text-xs px-2.5 py-1 bg-stone-100 hover:bg-stone-200 rounded-lg text-stone-600"
              >
                ปิด
              </button>
            </div>

            {/* Search & Filter */}
            <div className="flex flex-col sm:flex-row gap-2">
              <div className="relative flex-1">
                <Search className="w-4 h-4 text-stone-400 absolute left-3 top-2.5" />
                <input
                  type="text"
                  placeholder="พิมพ์ค้นหาชื่อจักรยาน, รหัสสินค้า, อะไหล่, บริการช่าง..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full pl-9 pr-3 py-2 text-xs bg-stone-50 border border-stone-300 rounded-xl"
                  autoFocus
                />
              </div>

              <select
                value={catalogFilterCategory}
                onChange={(e) => setCatalogFilterCategory(e.target.value)}
                className="text-xs bg-stone-50 border border-stone-300 rounded-xl px-3 py-2"
              >
                <option value="all">ทุกหมวดหมู่</option>
                <option value="bicycle">🚲 รถจักรยาน (Bicycles)</option>
                <option value="parts">⚙️ อะไหล่ & ชุดขับ (Parts)</option>
                <option value="accessories">🎒 อุปกรณ์ & แต่งรถ (Accessories)</option>
                <option value="service">🔧 บริการช่าง & ฟิตติ้ง (Services)</option>
              </select>
            </div>

            {/* Products List */}
            <div className="overflow-y-auto space-y-2 flex-1 pr-1">
              {filteredCatalog.map(prod => (
                <div
                  key={prod.id}
                  onClick={() => addItemFromCatalog(prod)}
                  className="p-3 rounded-xl border border-stone-200 hover:border-amber-400 hover:bg-amber-50/50 cursor-pointer transition-all flex items-center justify-between gap-3 group"
                >
                  <div className="space-y-0.5">
                    <div className="flex items-center gap-2">
                      <span className="text-[10px] font-mono font-bold px-1.5 py-0.5 rounded bg-stone-100 text-stone-700">
                        {prod.code}
                      </span>
                      <span className="text-xs font-bold text-stone-900 group-hover:text-amber-900">
                        {prod.name}
                      </span>
                    </div>
                    {prod.description && (
                      <p className="text-[11px] text-stone-500 line-clamp-1">{prod.description}</p>
                    )}
                  </div>

                  <div className="text-right shrink-0">
                    <span className="font-mono font-bold text-sm text-stone-900 group-hover:text-amber-700">
                      {formatCurrency(prod.price, true)}
                    </span>
                    <span className="text-[10px] text-stone-400 block">/{prod.unit}</span>
                  </div>
                </div>
              ))}
            </div>

          </div>
        </div>
      )}

    </div>
  );
};
