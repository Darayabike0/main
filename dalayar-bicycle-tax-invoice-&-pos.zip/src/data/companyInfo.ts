import { CompanyInfo } from '../types';

export const DALAYAR_COMPANY_INFO: CompanyInfo = {
  nameTh: 'บริษัท ดาลาญาร์ ไลฟ์สไตล์จักรยาน จำกัด (DARAYAR)',
  nameEn: 'DALAYAR BICYCLE LIFESTYLE COMPANY',
  shortName: 'DALAYAR BICYCLE',
  address: '5/1-5/2 หมู่ที่ 13 ต.มัญจาคีรี อ.มัญจาคีรี จ.ขอนแก่น 40160 (สำนักงานใหญ่)',
  taxId: '1401701236251',
  phone: '084-014-8961',
  email: 'darayadintt2543@gmail.com',
  website: 'www.dalayarbicycle.com',
  promptpayId: '1401701236251', // or 0840148961
  bankAccount: {
    bank: 'ธนาคารกสิกรไทย (KBANK)',
    accountName: 'บจก. ดาลาญาร์ ไลฟ์สไตล์จักรยาน',
    accountNumber: '140-1-70123-6',
    branch: 'สาขามัญจาคีรี',
  },
};
