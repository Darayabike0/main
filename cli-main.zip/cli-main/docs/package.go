// Package docs is an empty shell! This file is *only* meant to capture the dependencies
// required by the `gfmrun` documentation tests.

package docs

import (
	_ "github.com/urfave/cli-altsrc/v3"
	_ "github.com/urfave/cli/v3"
)
