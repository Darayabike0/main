---
tags:
  - v2
---

There are a small set of breaking changes between v2 and v3.
Converting is relatively straightforward and typically takes less than
an hour. Specific steps are included in
[Migration Guide: v2 to v3](../migrate-v2-to-v3.md).
